﻿'use strict';
/* ============================================================
   quiz-data.js  — 多言語クイズデータ（全20問）
   対応言語: ja / en / zh / vi / tl / id / my
   ============================================================ */
const QUIZ_DATA = [

  /* ===== Q1: ながら運転 ===== */
  {
    id: 1,
    question: {
      ja: '自転車に乗りながらスマートフォンを手に持って通話した。これはどんな違反ですか？',
      en: 'You held your smartphone and made a phone call while riding your bicycle. What violation is this?',
      zh: '骑自行车时手持智能手机通话。这属于哪种违规行为？',
      vi: 'Bạn vừa đạp xe vừa cầm điện thoại thông minh để gọi điện. Đây là vi phạm gì?',
      tl: 'Habang nagbibisikleta, hawak mo ang smartphone at tumawag. Anong uri ng paglabag ito?',
      id: 'Saat bersepeda, Anda memegang smartphone dan menelepon. Ini termasuk pelanggaran apa?',
      my: 'စက်ဘီးစီးနင်းစဉ် smartphone ကိုင်ကာ ဖုန်းဆက်သည်။ မည်သည့် ချိုးဖောက်မှုနည်း?',
      ko: '자전거를 타면서 스마트폰을 손에 들고 통화했습니다. 이것은 어떤 위반입니까?',
      fr: 'Vous teniez votre smartphone en main et téléphoniez tout en faisant du vélo. De quelle infraction s\'agit-il ?',
      it: 'Hai tenuto lo smartphone in mano e hai telefonato mentre andavi in bicicletta. Di quale violazione si tratta?',
      pt: 'Você segurou o smartphone e fez uma ligação enquanto andava de bicicleta. Que infração é essa?'
    },
    signImage: 'img/kiken01.png',
    category: 'ながら運転',
    choices: [
      {
        text: {
          ja: '片手運転になるが違反ではない',
          en: 'One-handed riding, but not a violation',
          zh: '单手骑车，但不算违规',
          vi: 'Lái xe một tay nhưng không vi phạm',
          tl: 'Isang kamay lang pero hindi paglabag',
          id: 'Berkendara satu tangan tapi bukan pelanggaran',
          my: 'တစ်ဘက်လက်ဖြင့် မောင်းသည်၊ ချိုးဖောက်မှု မဟုတ်',
          ko: '한 손 운전이 되지만 위반은 아니다',
          fr: 'Conduite à une main, mais pas une infraction',
          it: 'Guida con una mano sola, ma non è una violazione',
          pt: 'Andar com uma mão, mas não é uma infração'
        },
        correct: false
      },
      {
        text: {
          ja: 'ながら運転（携帯電話使用等）の違反',
          en: 'Distracted riding (mobile phone use) violation',
          zh: '边骑车边使用手机的违规行为',
          vi: 'Vi phạm lái xe mất tập trung (sử dụng điện thoại)',
          tl: 'Paglabag sa distracted riding (paggamit ng cellphone)',
          id: 'Pelanggaran berkendara sambil menggunakan HP',
          my: 'ဖုန်းသုံးကာ စီးနင်း ချိုးဖောက်မှု (ဆက်သွယ်ရေးကိရိယာ သုံးစွဲမှု)',
          ko: '주의분산 운전(휴대전화 사용 등)의 위반',
          fr: 'Infraction pour conduite distraite (utilisation du téléphone mobile)',
          it: 'Violazione per guida distratta (uso del telefono cellulare)',
          pt: 'Infração por condução distraída (uso de celular)'
        },
        correct: true
      },
      {
        text: {
          ja: '周囲に注意すれば問題ない',
          en: 'No problem as long as you watch your surroundings',
          zh: '只要注意周围就没问题',
          vi: 'Không sao nếu chú ý xung quanh',
          tl: 'Walang problema kung mapagmatyag sa paligid',
          id: 'Tidak masalah selama memperhatikan sekitar',
          my: 'ပတ်ဝန်းကျင် သတိထားလျှင် ပြဿနာမရှိ',
          ko: '주위에 주의하면 문제없다',
          fr: 'Pas de problème si vous surveillez vos alentours',
          it: 'Nessun problema se si presta attenzione all\'ambiente circostante',
          pt: 'Sem problema se prestar atenção ao redor'
        },
        correct: false
      },
      {
        text: {
          ja: 'ハンズフリーでないと違反',
          en: 'Only a violation without a hands-free device',
          zh: '不用免提才算违规',
          vi: 'Chỉ vi phạm khi không dùng thiết bị rảnh tay',
          tl: 'Paglabag lang kung walang hands-free device',
          id: 'Hanya pelanggaran jika tidak menggunakan hands-free',
          my: 'Hands-free မသုံးမှသာ ချိုးဖောက်မှု',
          ko: '핸즈프리가 아니면 위반',
          fr: 'Infraction uniquement sans dispositif mains libres',
          it: 'Infrazione solo senza dispositivo vivavoce',
          pt: 'Apenas infração sem dispositivo mãos-livres'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '自転車に乗りながらスマートフォンを手で保持して通話することは「携帯電話使用等（保持）」の違反です。2026年5月施行の改正道路交通法により自転車にも青切符が交付されます。',
      en: 'Holding a smartphone and making a call while cycling is a "mobile device use (holding)" violation. Under the revised Road Traffic Law effective May 2026, bicycles can also receive a blue ticket.',
      zh: '骑车时手持智能手机通话属于"手机使用（持有）"违规。根据2026年5月实施的修订道路交通法，自行车也将被开具蓝色罚单。',
      vi: 'Cầm điện thoại và gọi điện khi đang đạp xe là vi phạm "sử dụng điện thoại di động (cầm giữ)". Theo Luật Giao thông sửa đổi có hiệu lực tháng 5/2026, xe đạp cũng có thể bị phạt phiếu xanh.',
      tl: 'Ang paghawak ng smartphone at pagtawag habang nagbibisikleta ay paglabag sa "paggamit ng mobile phone (hawak)." Sa ilalim ng binagong batas trapiko na epektibo Mayo 2026, maaari ring makatanggap ng blue ticket ang bisikleta.',
      id: 'Memegang smartphone sambil bersepeda dan menelepon adalah pelanggaran "penggunaan HP (memegang)." Berdasarkan revisi UU Lalu Lintas yang berlaku Mei 2026, sepeda pun bisa mendapat blue ticket.',
      my: 'စက်ဘီးစီးနင်းစဉ် smartphone ကိုင်ကာ ဖုန်းဆက်ခြင်းသည် "မိုဘိုင်းကိရိယာ သုံးစွဲမှု (ကိုင်ဆောင်ခြင်း)" ချိုးဖောက်မှုဖြစ်သည်။ ၂၀၂၆ ခုနှစ် မေလတွင် ပြင်ဆင်ထားသော လမ်းအသွားအလာ ဥပဒေ အသက်ဝင်ပြီး စက်ဘီးများကိုလည်း ဒဏ်ပေးနိုင်သည်။',
      ko: '자전거를 타면서 스마트폰을 손에 들고 통화하는 것은 "휴대전화 사용(보유)" 위반입니다. 2026년 5월 시행된 개정 도로교통법으로 자전거에도 파란 딱지가 발부됩니다.',
      fr: 'Tenir un smartphone et téléphoner en faisant du vélo constitue une infraction d\'« utilisation d\'appareil mobile (tenu en main) ». En vertu de la loi révisée sur la circulation routière en vigueur en mai 2026, les vélos peuvent également recevoir un ticket bleu.',
      it: 'Tenere uno smartphone in mano e telefonare mentre si va in bicicletta costituisce una violazione di "uso di dispositivo mobile (tenuto in mano)". In base alla revisione del Codice della Strada in vigore da maggio 2026, anche le biciclette possono ricevere un ticket blu.',
      pt: 'Segurar um smartphone e fazer uma ligação enquanto pedala é uma infração de "uso de dispositivo móvel (segurando)". Conforme a revisão da Lei de Trânsito em vigor a partir de maio de 2026, as bicicletas também podem receber um ticket azul.'
    },
    fineAmount: '6,000',
    criminal: false
  },

  /* ===== Q2: ながら運転（画面注視） ===== */
  {
    id: 2,
    question: {
      ja: '自転車で走行中、ポケットからスマホを取り出し画面を見ながら走った。問題はありますか？',
      en: 'While cycling, you took out your smartphone and looked at the screen as you rode. Is this a problem?',
      zh: '骑自行车途中，从口袋取出手机边看屏幕边骑。这有问题吗？',
      vi: 'Trong khi đạp xe, bạn lấy điện thoại ra và vừa nhìn màn hình vừa đi. Điều này có vấn đề không?',
      tl: 'Habang nagbibisikleta, kinuha mo ang smartphone mula sa bulsa at tumingin sa screen habang nagmamaneho. May problema ba ito?',
      id: 'Saat bersepeda, Anda mengeluarkan smartphone dari saku dan melihat layar sambil mengayuh. Apakah ini bermasalah?',
      my: 'စက်ဘီးစီးနင်းစဉ် အိတ်ကပ်မှ smartphone ထုတ်ကာ မျက်နှာပြင်ကြည့်ရင်း မောင်းသည်။ ပြဿနာရှိသလား?',
      ko: '자전거를 타는 중에 주머니에서 스마트폰을 꺼내 화면을 보면서 달렸습니다. 문제가 있습니까?',
      fr: 'Pendant que vous faisiez du vélo, vous avez sorti votre smartphone de votre poche et avez regardé l\'écran en roulant. Est-ce un problème ?',
      it: 'Mentre andavi in bicicletta, hai tirato fuori lo smartphone dalla tasca e hai guardato lo schermo mentre pedalavi. C\'è un problema?',
      pt: 'Enquanto pedalava, você tirou o smartphone do bolso e olhou para a tela enquanto andava. Isso é um problema?'
    },
    signImage: 'img/kiken02.png',
    category: 'ながら運転',
    choices: [
      {
        text: {
          ja: '一瞬なら問題ない',
          en: 'No problem if it is just a glance',
          zh: '只看一眼没问题',
          vi: 'Chỉ liếc qua thì không sao',
          tl: 'Walang problema kung sandali lang',
          id: 'Tidak masalah jika hanya sebentar',
          my: 'တစ်ချက်ကြည့်ရုံမျှ ပြဿနာမရှိ',
          ko: '잠깐이면 문제없다',
          fr: 'Pas de problème si c\'est juste un coup d\'œil',
          it: 'Nessun problema se è solo un\'occhiata',
          pt: 'Sem problema se for apenas uma olhada rápida'
        },
        correct: false
      },
      {
        text: {
          ja: '止まってから見れば問題ない（走行中は違反）',
          en: 'Fine if you stop first — looking while moving is a violation',
          zh: '停车后再看没问题（行驶中看是违规）',
          vi: 'Dừng lại rồi xem thì không sao — xem khi đang chạy là vi phạm',
          tl: 'Okay kung huminto muna — pagtingin habang gumagalaw ay paglabag',
          id: 'Boleh jika berhenti dulu — melihat saat bergerak adalah pelanggaran',
          my: 'ရပ်ပြီးမှ ကြည့်လျှင် ပြဿနာမရှိ — မောင်းစဉ် ကြည့်ခြင်းသည် ချိုးဖောက်မှု',
          ko: '멈추고 나서 보면 문제없다（주행 중은 위반）',
          fr: 'Pas de problème si vous vous arrêtez d\'abord — regarder en roulant est une infraction',
          it: 'Nessun problema se ci si ferma prima — guardare mentre si è in movimento è una violazione',
          pt: 'Sem problema se parar primeiro — olhar enquanto se move é uma infração'
        },
        correct: true
      },
      {
        text: {
          ja: '歩道なら問題ない',
          en: 'No problem on a sidewalk',
          zh: '在人行道上没问题',
          vi: 'Trên vỉa hè thì không sao',
          tl: 'Walang problema sa sidewalk',
          id: 'Tidak masalah di trotoar',
          my: 'လမ်းလျှောက်ကွင်းတွင်ဆိုလျှင် ပြဿနာမရှိ',
          ko: '인도라면 문제없다',
          fr: 'Pas de problème sur le trottoir',
          it: 'Nessun problema sul marciapiede',
          pt: 'Sem problema na calçada'
        },
        correct: false
      },
      {
        text: {
          ja: 'ながら運転は自動車だけの規制',
          en: 'Distracted riding rules apply only to cars',
          zh: '边走边看手机只是针对汽车的规定',
          vi: 'Quy định lái xe mất tập trung chỉ áp dụng cho ô tô',
          tl: 'Ang distracted riding rules ay para lang sa mga sasakyan',
          id: 'Aturan berkendara sambil main HP hanya untuk mobil',
          my: 'မောင်းရင်းဖုန်းကြည့်ဆိုသည်မှာ ကားများအတွက်သာ စည်းကမ်းရှိ',
          ko: '주의분산 운전은 자동차만의 규제',
          fr: 'Les règles de conduite distraite s\'appliquent uniquement aux voitures',
          it: 'Le norme sulla guida distratta si applicano solo alle automobili',
          pt: 'As regras de condução distraída aplicam-se apenas a carros'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '走行中に画面を注視する行為は「携帯電話使用等（画像目視）」に該当し、自転車でも違反です。交差点や歩道での事故リスクが非常に高く、危険性があると判断されればより重い罰則が適用される場合もあります。',
      en: 'Looking at a screen while riding is classified as "mobile device use (screen viewing)" and is a violation even on a bicycle. The accident risk at intersections and on sidewalks is very high, and more serious penalties may apply if the behavior is deemed dangerous.',
      zh: '行驶中注视手机屏幕属于"手机使用（图像查看）"违规，骑自行车也不例外。在路口和人行道发生事故的风险极高，若被认定具有危险性，可能面临更重的处罚。',
      vi: 'Nhìn vào màn hình khi đang đạp xe được xếp vào "sử dụng điện thoại di động (xem màn hình)" và là vi phạm dù trên xe đạp. Nguy cơ tai nạn tại ngã tư và trên vỉa hè rất cao; có thể bị phạt nặng hơn nếu bị coi là nguy hiểm.',
      tl: 'Ang pagtingin sa screen habang nagmamaneho ay "paggamit ng mobile device (pagtingin sa screen)" at paglabag kahit sa bisikleta. Napakataas ng panganib ng aksidente sa interseksyon at sidewalk; maaaring mas mabigat na parusa kung ituturing na mapanganib.',
      id: 'Melihat layar saat bersepeda termasuk "penggunaan HP (melihat layar)" dan tetap merupakan pelanggaran. Risiko kecelakaan di persimpangan dan trotoar sangat tinggi, dan sanksi yang lebih berat bisa diterapkan jika dianggap berbahaya.',
      my: 'မောင်းနင်းစဉ် မျက်နှာပြင်ကြည့်ခြင်းသည် "မိုဘိုင်းကိရိယာ သုံးစွဲမှု (မျက်နှာပြင် ကြည့်ရှုခြင်း)" ဟု သတ်မှတ်ပြီး စက်ဘီးတွင်လည်း ချိုးဖောက်မှုဖြစ်သည်။ လမ်းဆုံနှင့် လမ်းလျှောက်ကွင်းတို့တွင် မတော်တဆမှု ဖြစ်နိုင်ချေ မြင့်မားသည်။',
      ko: '달리면서 화면을 바라보는 행위는 "휴대전화 사용(영상 주시)"에 해당하며, 자전거도 위반입니다. 교차로와 보도에서 사고 위험이 매우 높으며, 위험하다고 판단되면 더 무거운 처벌이 적용될 수도 있습니다.',
      fr: 'Regarder un écran en faisant du vélo est classé comme « utilisation d\'appareil mobile (regarder l\'écran) » et constitue une infraction même à vélo. Le risque d\'accident aux carrefours et sur les trottoirs est très élevé ; des sanctions plus sévères peuvent s\'appliquer si le comportement est jugé dangereux.',
      it: 'Guardare lo schermo mentre si va in bicicletta è classificato come "uso di dispositivo mobile (visualizzazione schermo)" ed è una violazione anche in bicicletta. Il rischio di incidenti agli incroci e sui marciapiedi è molto elevato; possono applicarsi sanzioni più severe se il comportamento viene ritenuto pericoloso.',
      pt: 'Olhar para uma tela enquanto pedala é classificado como "uso de dispositivo móvel (visualização de tela)" e é uma infração mesmo de bicicleta. O risco de acidente em cruzamentos e calçadas é muito alto; penalidades mais severas podem se aplicar se o comportamento for considerado perigoso.'
    },
    fineAmount: '6,000',
    criminal: false
  },

  /* ===== Q3: ながら運転（イヤホン） ===== */
  {
    id: 3,
    question: {
      ja: '自転車に乗りながらイヤホンを両耳につけて音楽を聴いた。どうなりますか？',
      en: 'You wore earphones in both ears and listened to music while cycling. What happens?',
      zh: '骑自行车时双耳戴耳机听音乐。会有什么问题？',
      vi: 'Bạn đeo tai nghe cả hai tai và nghe nhạc trong khi đạp xe. Điều gì sẽ xảy ra?',
      tl: 'Nagsuot ka ng earphone sa magkabilang tainga at nakinig ng musika habang nagbibisikleta. Ano ang mangyayari?',
      id: 'Anda memakai earphone di kedua telinga dan mendengarkan musik saat bersepeda. Apa yang akan terjadi?',
      my: 'စက်ဘီးစီးနင်းစဉ် နားကြပ်နှစ်ဘက်ပြည့် တပ်ဆင်ကာ သီချင်းနားထောင်သည်။ မည်သို့ ဖြစ်မည်နည်း?',
      ko: '자전거를 타면서 양쪽 귀에 이어폰을 꽂고 음악을 들었습니다. 어떻게 됩니까?',
      fr: 'Vous avez mis des écouteurs dans les deux oreilles et écouté de la musique tout en faisant du vélo. Que se passe-t-il ?',
      it: 'Hai indossato gli auricolari in entrambe le orecchie e ascoltato musica mentre andavi in bicicletta. Cosa succede?',
      pt: 'Você usou fones de ouvido em ambos os ouvidos e ouviu música enquanto andava de bicicleta. O que acontece?'
    },
    signImage: 'img/kiken03.png',
    category: 'ながら運転',
    choices: [
      {
        text: {
          ja: '音量を小さくすれば問題ない',
          en: 'No problem if you keep the volume low',
          zh: '音量小就没问题',
          vi: 'Không sao nếu giảm âm lượng',
          tl: 'Walang problema kung mababa ang volume',
          id: 'Tidak masalah jika volume kecil',
          my: 'အသံချဲ့မှု နှိမ့်ချထားလျှင် ပြဿနာမရှိ',
          ko: '음량을 낮추면 문제없다',
          fr: 'Pas de problème si le volume est bas',
          it: 'Nessun problema se il volume è basso',
          pt: 'Sem problema se o volume estiver baixo'
        },
        correct: false
      },
      {
        text: {
          ja: '片耳だけなら問題ない',
          en: 'No problem with only one ear',
          zh: '只戴一只耳机没问题',
          vi: 'Chỉ một tai thì không sao',
          tl: 'Walang problema kung isang tainga lang',
          id: 'Tidak masalah jika hanya satu telinga',
          my: 'တစ်ဘက်နားသာ ဆိုလျှင် ပြဿနာမရှိ',
          ko: '한쪽 귀만이면 문제없다',
          fr: 'Pas de problème avec une seule oreille',
          it: 'Nessun problema con un solo orecchio',
          pt: 'Sem problema com apenas um ouvido'
        },
        correct: false
      },
      {
        text: {
          ja: '周囲の音が聞こえない状態は違反になる',
          en: 'Being unable to hear surrounding sounds is a violation',
          zh: '无法听到周围声音的状态属于违规',
          vi: 'Không thể nghe âm thanh xung quanh là vi phạm',
          tl: 'Ang hindi makarinig ng mga tunog sa paligid ay paglabag',
          id: 'Tidak dapat mendengar suara sekitar merupakan pelanggaran',
          my: 'ပတ်ဝန်းကျင် အသံ မကြားနိုင်သော အခြေအနေသည် ချိုးဖောက်မှု',
          ko: '주변 소리가 들리지 않는 상태는 위반이 된다',
          fr: 'Ne pas pouvoir entendre les sons environnants est une infraction',
          it: 'Non riuscire a sentire i suoni circostanti è una violazione',
          pt: 'Não conseguir ouvir os sons ao redor é uma infração'
        },
        correct: true
      },
      {
        text: {
          ja: '骨伝導イヤホンなら常に問題ない',
          en: 'Bone-conduction earphones are always fine',
          zh: '骨传导耳机永远没问题',
          vi: 'Tai nghe dẫn truyền xương thì luôn không sao',
          tl: 'Ang bone-conduction earphone ay palaging okay',
          id: 'Earphone konduksi tulang selalu tidak masalah',
          my: 'အရိုးဆက်ပြေး နားကြပ်ဆိုလျှင် အမြဲပြဿနာမရှိ',
          ko: '골전도 이어폰이라면 항상 문제없다',
          fr: 'Les écouteurs à conduction osseuse sont toujours acceptables',
          it: 'Gli auricolari a conduzione ossea sono sempre accettabili',
          pt: 'Fones de condução óssea são sempre permitidos'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '両耳にイヤホンをつけて周囲の音が聞こえない状態での運転は、都道府県の交通規則により「安全運転義務違反」等に問われます。緊急車両のサイレンや他者の警告が聞こえず重大事故につながります。',
      en: 'Riding with earphones in both ears so you cannot hear surrounding sounds may be cited as a "safe driving obligation violation" under prefectural traffic rules. Missing emergency sirens or warnings from others can lead to serious accidents.',
      zh: '双耳戴耳机导致无法听到周围声音，根据各都道府县交通规则，可能被追究"安全驾驶义务违反"等责任。听不到救护车警报或他人警告，可能引发严重事故。',
      vi: 'Đeo tai nghe cả hai tai khiến không nghe được âm thanh xung quanh có thể bị xử phạt "vi phạm nghĩa vụ lái xe an toàn" theo quy định giao thông của từng tỉnh. Không nghe thấy còi xe cứu thương hay cảnh báo của người khác có thể dẫn đến tai nạn nghiêm trọng.',
      tl: 'Ang pagsakay nang may earphone sa magkabilang tainga na hindi makarinig ng mga tunog sa paligid ay maaaring makulong bilang "paglabag sa ligtas na pagmamaneho" ayon sa mga lokal na regulasyon. Ang hindi pakiramdam ng sirena ng emergency o babala ng iba ay maaaring magdulot ng malubhang aksidente.',
      id: 'Bersepeda dengan earphone di kedua telinga sehingga tidak dapat mendengar suara sekitar dapat dikenai "pelanggaran kewajiban berkendara aman" sesuai peraturan lalu lintas prefektur. Tidak mendengar sirene kendaraan darurat atau peringatan orang lain bisa menyebabkan kecelakaan serius.',
      my: 'နားကြပ်နှစ်ဘက်တပ်ဆင်ကာ ပတ်ဝန်းကျင် အသံ မကြားနိုင်သော အခြေအနေတွင် စီးနင်းခြင်းသည် ခရိုင်ဆိုင်ရာ ယာဉ်ကြောစည်းကမ်းများအရ "လုံခြုံသောမောင်းနှင်မှု တာဝန်ဝတ္တရားချိုးဖောက်ခြင်း" ဟု ယူဆနိုင်သည်။',
      ko: '양쪽 귀에 이어폰을 꽂아 주변 소리가 들리지 않는 상태로 운전하면, 도도부현의 교통 규칙에 의해 "안전 운전 의무 위반" 등으로 처분될 수 있습니다. 긴급 차량 사이렌이나 타인의 경고를 듣지 못해 심각한 사고로 이어질 수 있습니다.',
      fr: 'Faire du vélo avec des écouteurs dans les deux oreilles de façon à ne pas entendre les sons environnants peut être sanctionné comme « violation de l\'obligation de conduite sécurisée » selon les règlements de circulation préfectoraux. Ne pas entendre les sirènes de secours ou les avertissements des autres peut mener à des accidents graves.',
      it: 'Andare in bicicletta con gli auricolari in entrambe le orecchie in modo da non riuscire a sentire i suoni circostanti può essere citato come "violazione dell\'obbligo di guida sicura" secondo i regolamenti stradali prefetturali. Non sentire le sirene di emergenza o gli avvertimenti altrui può portare a gravi incidenti.',
      pt: 'Andar de bicicleta com fones de ouvido nos dois ouvidos de forma a não conseguir ouvir os sons ao redor pode ser citado como "violação da obrigação de condução segura" de acordo com os regulamentos de trânsito da prefeitura. Não ouvir sirenes de emergência ou avisos de terceiros pode levar a acidentes graves.'
    },
    fineAmount: '3,000〜6,000',
    criminal: false
  },

  /* ===== Q4: ながら運転（傘差し） ===== */
  {
    id: 4,
    question: {
      ja: '自転車走行中に傘を片手でさしながら雨の中を走った。この行為は？',
      en: 'You held an umbrella with one hand while cycling in the rain. What is this behavior?',
      zh: '骑自行车时单手撑伞在雨中行驶。这种行为如何？',
      vi: 'Bạn cầm ô bằng một tay khi đạp xe trong mưa. Hành động này như thế nào?',
      tl: 'Humawak ka ng payong ng isang kamay habang nagbibisikleta sa ulan. Ano ang gawaing ito?',
      id: 'Anda memegang payung dengan satu tangan saat bersepeda di tengah hujan. Apa tindakan ini?',
      my: 'မိုးထဲတွင် စက်ဘီးစီးနင်းစဉ် တစ်ဘက်လက်ဖြင့် ထီးကိုင်၍ မောင်းသည်။ ဤလုပ်ရပ်မှာ?',
      ko: '자전거를 타면서 한 손으로 우산을 잡고 빗속을 달렸습니다. 이 행위는?',
      fr: 'Vous avez tenu un parapluie d\'une main tout en faisant du vélo sous la pluie. Comment qualifier ce comportement ?',
      it: 'Hai tenuto un ombrello con una mano mentre andavi in bicicletta sotto la pioggia. Come si qualifica questo comportamento?',
      pt: 'Você segurou um guarda-chuva com uma mão enquanto andava de bicicleta na chuva. Como classificar esse comportamento?'
    },
    signImage: 'img/kiken04.png',
    category: 'ながら運転',
    choices: [
      {
        text: {
          ja: '小雨なら問題ない',
          en: 'No problem in light rain',
          zh: '小雨没问题',
          vi: 'Mưa nhỏ thì không sao',
          tl: 'Walang problema sa magaang na ulan',
          id: 'Tidak masalah saat hujan ringan',
          my: 'မိုးသေးသေးဆိုလျှင် ပြဿနာမရှိ',
          ko: '가랑비라면 문제없다',
          fr: 'Pas de problème sous une pluie légère',
          it: 'Nessun problema con pioggia leggera',
          pt: 'Sem problema em chuva leve'
        },
        correct: false
      },
      {
        text: {
          ja: '歩道を走るなら傘を差してもよい',
          en: 'Using an umbrella is fine on a sidewalk',
          zh: '在人行道骑车可以撑伞',
          vi: 'Dùng ô trên vỉa hè thì được',
          tl: 'Okay ang payong sa sidewalk',
          id: 'Payung boleh digunakan di trotoar',
          my: 'လမ်းလျှောက်ကွင်းတွင် ဆိုလျှင် ထီးကိုင်ပါ သွားနိုင်သည်',
          ko: '인도를 달린다면 우산을 써도 좋다',
          fr: 'L\'utilisation d\'un parapluie est acceptable sur le trottoir',
          it: 'Usare un ombrello è accettabile sul marciapiede',
          pt: 'Usar guarda-chuva é permitido na calçada'
        },
        correct: false
      },
      {
        text: {
          ja: '傘差し運転は安全運転義務違反',
          en: 'Riding with an umbrella is a safe-driving obligation violation',
          zh: '撑伞骑车属于违反安全驾驶义务',
          vi: 'Đi xe đạp cầm ô là vi phạm nghĩa vụ lái xe an toàn',
          tl: 'Ang pagsakay na may payong ay paglabag sa safe-driving obligation',
          id: 'Bersepeda sambil memegang payung melanggar kewajiban berkendara aman',
          my: 'ထီးကိုင်ကာ စီးနင်းခြင်းသည် လုံခြုံသောမောင်းနှင်မှု တာဝန်ဝတ္တရားချိုးဖောက်ခြင်း',
          ko: '우산 쓰고 자전거 타기는 안전 운전 의무 위반',
          fr: 'Faire du vélo avec un parapluie constitue une violation de l\'obligation de conduite sécurisée',
          it: 'Andare in bicicletta con l\'ombrello costituisce una violazione dell\'obbligo di guida sicura',
          pt: 'Andar de bicicleta com guarda-chuva é uma violação da obrigação de condução segura'
        },
        correct: true
      },
      {
        text: {
          ja: '片手でも安全に走れれば問題ない',
          en: 'No problem if you can ride safely one-handed',
          zh: '单手能安全骑行就没问题',
          vi: 'Không sao nếu có thể đi xe an toàn bằng một tay',
          tl: 'Walang problema kung ligtas na makasakay ng isang kamay',
          id: 'Tidak masalah jika bisa berkendara aman dengan satu tangan',
          my: 'တစ်ဘက်လက်ဖြင့် လုံခြုံစွာ မောင်းနင်းနိုင်လျှင် ပြဿနာမရှိ',
          ko: '한 손으로도 안전하게 달릴 수 있으면 문제없다',
          fr: 'Pas de problème si vous pouvez rouler en sécurité avec une seule main',
          it: 'Nessun problema se si può andare in bicicletta in modo sicuro con una sola mano',
          pt: 'Sem problema se puder andar com segurança com uma mão'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '傘を片手で差しながら自転車を運転する「傘差し運転」は、ハンドル操作が不十分になり安全運転義務違反に該当します。2026年5月施行の改正道路交通法で青切符の対象です。雨天時はレインコートを使用しましょう。',
      en: '"Umbrella riding" — holding an umbrella with one hand while cycling — impairs steering control and is a safe-driving obligation violation. It is subject to a blue ticket under the revised Road Traffic Law effective May 2026. Use a raincoat in wet weather.',
      zh: '单手撑伞骑自行车的"撑伞骑行"行为，会导致把手操作不足，属于违反安全驾驶义务。依据2026年5月实施的修订道路交通法，将被开具蓝色罚单。雨天请使用雨衣。',
      vi: '"Đi xe đạp cầm ô" — cầm ô bằng một tay khi đạp xe — làm giảm khả năng điều khiển tay lái và là vi phạm nghĩa vụ lái xe an toàn. Sẽ bị phạt phiếu xanh theo Luật Giao thông sửa đổi có hiệu lực tháng 5/2026. Hãy mặc áo mưa khi trời mưa.',
      tl: 'Ang "umbrella riding" — paghawak ng payong ng isang kamay habang nagbibisikleta — ay nagpapahina ng kontrol sa manibela at paglabag sa safe-driving obligation. Sakop ng blue ticket sa ilalim ng binagong batas trapiko na epektibo Mayo 2026. Gumamit ng raincoat sa mauvlan na panahon.',
      id: '"Berkendara dengan payung" — memegang payung satu tangan saat bersepeda — mengurangi kemampuan mengendalikan setang dan melanggar kewajiban berkendara aman. Dikenai blue ticket berdasarkan revisi UU Lalu Lintas Mei 2026. Gunakan jas hujan saat hujan.',
      my: 'ထီးကိုင်ကာ စီးနင်းသည့် "ထီးကိုင်စီး" ပုံစံသည် ဘောင်းပတ်ကို မှန်ကန်စွာ မကိုင်နိုင်သောကြောင့် လုံခြုံသောမောင်းနှင်မှု တာဝန်ဝတ္တရားချိုးဖောက်ခြင်း ဖြစ်သည်။ မိုးရာသီတွင် မိုးကာဝတ်ကို သုံးပါ။',
      ko: '"우산 쓰고 타기" — 한 손으로 우산을 잡고 자전거를 운전하는 것 — 은 핸들 조작이 불충분해져 안전 운전 의무 위반에 해당합니다. 2026년 5월 시행된 개정 도로교통법으로 파란 딱지의 대상입니다. 비가 올 때는 우비를 사용하세요.',
      fr: '"Conduire avec un parapluie" — tenir un parapluie d\'une main en faisant du vélo — compromet le contrôle du guidon et constitue une violation de l\'obligation de conduite sécurisée. Passible d\'un ticket bleu en vertu de la loi révisée en vigueur en mai 2026. Utilisez un imperméable par temps de pluie.',
      it: '"Guidare con l\'ombrello" — tenere un ombrello con una mano mentre si va in bicicletta — compromette il controllo del manubrio ed è una violazione dell\'obbligo di guida sicura. È soggetto a ticket blu ai sensi della revisione del Codice della Strada in vigore da maggio 2026. Usate un impermeabile quando piove.',
      pt: '"Pedalar com guarda-chuva" — segurar um guarda-chuva com uma mão enquanto pedala — compromete o controle do guidão e é uma violação da obrigação de condução segura. Sujeito a ticket azul conforme a revisão da Lei de Trânsito em vigor a partir de maio de 2026. Use uma capa de chuva quando chover.'
    },
    fineAmount: '3,000',
    criminal: false
  },

  /* ===== Q5: 酒気帯び運転 ===== */
  {
    id: 5,
    question: {
      ja: 'お酒を飲んだ後に自転車に乗ってはいけない理由として、正しいものはどれですか？',
      en: 'Which of the following correctly explains why you must not ride a bicycle after drinking?',
      zh: '以下哪项正确说明了饮酒后不能骑自行车的原因？',
      vi: 'Điều nào sau đây giải thích đúng lý do tại sao không được đi xe đạp sau khi uống rượu?',
      tl: 'Alin sa mga sumusunod ang tamang paliwanag kung bakit hindi dapat magbisikleta pagkatapos uminom?',
      id: 'Mana yang benar menjelaskan mengapa tidak boleh bersepeda setelah minum alkohol?',
      my: 'အောက်ပါတို့တွင် အရက်သောက်ပြီးနောက် စက်ဘီးမစီးသင့်ရသည့် အကြောင်းရင်းကို မှန်ကန်စွာ ရှင်းပြသည်မှာ အဘယ်နည်း?',
      ko: '술을 마신 후 자전거를 타면 안 되는 이유로 올바른 것은 어느 것입니까?',
      fr: 'Laquelle des propositions suivantes explique correctement pourquoi vous ne devez pas faire du vélo après avoir bu de l\'alcool ?',
      it: 'Quale delle seguenti affermazioni spiega correttamente perché non si deve andare in bicicletta dopo aver bevuto alcolici?',
      pt: 'Qual das seguintes opções explica corretamente por que não se deve andar de bicicleta após beber?'
    },
    signImage: 'img/kiken05.png',
    category: '酒気帯び運転',
    choices: [
      {
        text: {
          ja: '自転車は飲酒運転の規則に含まれない',
          en: 'Bicycles are not covered by drunk-riding rules',
          zh: '自行车不在酒驾规定范围内',
          vi: 'Xe đạp không thuộc phạm vi quy định lái xe say rượu',
          tl: 'Hindi saklaw ng mga patakaran sa drunk riding ang bisikleta',
          id: 'Sepeda tidak termasuk dalam aturan berkendara mabuk',
          my: 'စက်ဘီးသည် မူးယစ်မောင်းနှင်မှုဆိုင်ရာ စည်းကမ်းတွင် မပါဝင်',
          ko: '자전거는 음주 운전 규정에 포함되지 않는다',
          fr: 'Les vélos ne sont pas couverts par les règles de conduite en état d\'ivresse',
          it: 'Le biciclette non sono coperte dalle norme sulla guida in stato di ebbrezza',
          pt: 'As bicicletas não são cobertas pelas regras de condução embriagado'
        },
        correct: false
      },
      {
        text: {
          ja: 'ふらついて事故を起こしやすく、法律で禁止されている',
          en: 'Alcohol causes unsteady riding and accidents, and it is banned by law',
          zh: '容易摇摇晃晃发生事故，且法律明令禁止',
          vi: 'Rượu gây mất thăng bằng và tai nạn, và bị pháp luật cấm',
          tl: 'Nagdudulot ng pagkakaroon ng aksidente dahil sa pagkawala ng balanse, at ipinagbabawal ng batas',
          id: 'Alkohol menyebabkan oleng dan kecelakaan, serta dilarang oleh hukum',
          my: 'မတည်ငြိမ်မှု ဖြစ်ပေါ်ပြီး မတော်တဆမှု ဖြစ်နိုင်သည်၊ ထို့ပြင် ဥပဒေအရ တားမြစ်ထားသည်',
          ko: '비틀거려 사고를 일으키기 쉽고, 법률로 금지되어 있다',
          fr: 'L\'alcool provoque des zigzags et des accidents, et c\'est interdit par la loi',
          it: 'L\'alcol causa instabilità e incidenti, ed è vietato dalla legge',
          pt: 'O álcool causa instabilidade e acidentes, sendo proibido por lei'
        },
        correct: true
      },
      {
        text: {
          ja: '歩道を走れば大丈夫',
          en: 'It is fine to ride on the sidewalk',
          zh: '走人行道就没问题',
          vi: 'Đi trên vỉa hè thì không sao',
          tl: 'Okay lang kung sa sidewalk magmaneho',
          id: 'Tidak masalah jika bersepeda di trotoar',
          my: 'လမ်းလျှောက်ကွင်းပေါ်တွင် ဆိုလျှင် ရပါသည်',
          ko: '인도를 달리면 괜찮다',
          fr: 'C\'est acceptable de rouler sur le trottoir',
          it: 'Va bene andare sul marciapiede',
          pt: 'Tudo bem pedalar na calçada'
        },
        correct: false
      },
      {
        text: {
          ja: '近所なら問題ない',
          en: 'No problem for short distances nearby',
          zh: '附近的话没问题',
          vi: 'Gần nhà thì không sao',
          tl: 'Walang problema kung malapit lang',
          id: 'Tidak masalah jika jaraknya dekat',
          my: 'နီးနားလျှင် ပြဿနာမရှိ',
          ko: '근처라면 문제없다',
          fr: 'Pas de problème si c\'est à courte distance',
          it: 'Nessun problema per brevi distanze nelle vicinanze',
          pt: 'Sem problema para distâncias curtas nas redondezas'
        },
        correct: false
      }
    ],
    explanation: {
      ja: 'お酒を飲むと判断力や運動能力が下がり、ふらついて歩行者や車にぶつかる危険があります。自転車の飲酒運転は道路交通法で厳しく禁止されており、重い罰則があります。「少しだから」「近くだから」は通じません。絶対にやめましょう。',
      en: 'Alcohol impairs judgment and coordination, making you wobble and risk colliding with pedestrians or vehicles. Drunk cycling is strictly prohibited under the Road Traffic Law and carries heavy penalties. "Just a little" or "only nearby" are not excuses. Never do it.',
      zh: '饮酒会降低判断力和运动能力，容易摇晃撞上行人或车辆。自行车酒驾在《道路交通法》中被严格禁止，处罚严厉。"只喝了一点"或"距离很近"都不是理由，请务必杜绝。',
      vi: 'Rượu làm giảm khả năng phán đoán và phối hợp, khiến bạn loạng choạng và có nguy cơ va chạm với người đi bộ hoặc phương tiện khác. Đạp xe sau khi uống rượu bị nghiêm cấm theo Luật Giao thông và chịu hình phạt nặng. "Chỉ uống một chút" hay "gần nhà thôi" không phải là lý do. Tuyệt đối không làm vậy.',
      tl: 'Pinipigilan ng alkohol ang pagpapasya at koordinasyon, na nagpapanganib na mabangga ang mga pedestrian o sasakyan. Ang drunk cycling ay mahigpit na ipinagbabawal ng Road Traffic Law at may mabigat na parusa. "Kaunti lang" o "malapit lang" ay hindi dahilan. Huwag gawin.',
      id: 'Alkohol mengganggu penilaian dan koordinasi, membuat Anda oleng dan berisiko menabrak pejalan kaki atau kendaraan. Bersepeda dalam keadaan mabuk dilarang keras oleh UU Lalu Lintas dan dikenai sanksi berat. "Hanya sedikit" atau "dekat saja" bukan alasan. Jangan pernah lakukan.',
      my: 'အရက်သောက်ခြင်းသည် ဆုံးဖြတ်ချက်ချနိုင်မှုနှင့် ကိုယ်ခန္ဓာ တော်တောင့်မှုကို လျော့နည်းစေပြီး လမ်းလျှောက်သူများနှင့် ယာဉ်များကို တိုက်မိနိုင်သည်။ အရက်မူးကာ စက်ဘီးစီးနင်းခြင်းကို လမ်းအသွားအလာ ဥပဒေဖြင့် တင်းကျပ်စွာ တားမြစ်ထားသည်။',
      ko: '술을 마시면 판단력과 운동 능력이 떨어져 비틀거리며 보행자나 차량에 부딪힐 위험이 있습니다. 자전거 음주 운전은 도로교통법으로 엄격히 금지되어 있으며 무거운 처벌이 있습니다. "조금이니까"나 "가까우니까"는 통하지 않습니다. 절대 하지 마세요.',
      fr: 'L\'alcool altère le jugement et la coordination, vous faisant osciller et risquant de heurter des piétons ou des véhicules. Le vélo en état d\'ivresse est strictement interdit par le Code de la route et entraîne de lourdes sanctions. « Juste un peu » ou « juste à côté » ne sont pas des excuses. Ne le faites jamais.',
      it: 'L\'alcol compromette il giudizio e la coordinazione, facendovi oscillare e rischiando di collidere con pedoni o veicoli. Andare in bicicletta in stato di ebbrezza è severamente vietato dal Codice della Strada e comporta pesanti sanzioni. "Solo un po\'" o "è vicino" non sono scuse. Non fatelo mai.',
      pt: 'O álcool prejudica o julgamento e a coordenação, fazendo você cambalear e arriscar colidir com pedestres ou veículos. Pedalar bêbado é estritamente proibido pela Lei de Trânsito e acarreta pesadas penalidades. "Apenas um pouco" ou "é perto" não são desculpas. Nunca faça isso.'
    },
    fineAmount: null,
    criminal: true
  },

  /* ===== Q6: 二人乗り ===== */
  {
    id: 6,
    question: {
      ja: '友達を自転車の後ろに乗せて2人で走った。これは違反になりますか？',
      en: 'You let a friend ride on the back of your bicycle and rode together. Is this a violation?',
      zh: '让朋友坐在自行车后座一起骑行。这算违规吗？',
      vi: 'Bạn để bạn bè ngồi sau xe đạp của mình và cùng đạp. Đây có phải vi phạm không?',
      tl: 'Pinasakay mo ang kaibigan sa likod ng iyong bisikleta at nagmaneho kayo. Paglabag ba ito?',
      id: 'Anda membawa teman naik di belakang sepeda dan bersepeda bersama. Apakah ini pelanggaran?',
      my: 'မိတ်ဆွေကို စက်ဘီးနောက်ကျော တင်ကာ နှစ်ဦးအတူ မောင်းသည်။ ဤသည် ချိုးဖောက်မှုလား?',
      ko: '친구를 자전거 뒤에 태워 두 명이서 달렸습니다. 이것은 위반이 됩니까?',
      fr: 'Vous avez fait monter un ami à l\'arrière de votre vélo et avez roulé ensemble. Est-ce une infraction ?',
      it: 'Hai fatto salire un amico sul retro della tua bicicletta e avete pedalato insieme. È una violazione?',
      pt: 'Você deixou um amigo sentar na garupa da sua bicicleta e pedalaram juntos. Isso é uma infração?'
    },
    signImage: 'img/kiken06.png',
    category: 'その他の違反',
    choices: [
      {
        text: {
          ja: '友達なら乗せてもよい',
          en: 'It is fine to carry a friend',
          zh: '朋友的话可以带',
          vi: 'Bạn bè thì được phép',
          tl: 'Okay kung kaibigan ang sinasakay',
          id: 'Boleh jika yang dibawa teman',
          my: 'မိတ်ဆွေဆိုလျှင် တင်ခွင့်ရှိသည်',
          ko: '친구라면 태워도 좋다',
          fr: 'C\'est acceptable si c\'est un ami',
          it: 'Va bene se è un amico',
          pt: 'Tudo bem se for um amigo'
        },
        correct: false
      },
      {
        text: {
          ja: '歩道なら2人乗りしてもよい',
          en: 'Two people are allowed on a sidewalk',
          zh: '在人行道可以两人骑',
          vi: 'Được phép hai người trên vỉa hè',
          tl: 'Dalawang tao ay okay sa sidewalk',
          id: 'Dua orang boleh di trotoar',
          my: 'လမ်းလျှောက်ကွင်းတွင် ဆိုလျှင် နှစ်ဦးစီးနင်းခွင့်ရှိ',
          ko: '인도라면 두 명이 타도 좋다',
          fr: 'Deux personnes sont autorisées sur le trottoir',
          it: 'Due persone sono permesse sul marciapiede',
          pt: 'Duas pessoas são permitidas na calçada'
        },
        correct: false
      },
      {
        text: {
          ja: '原則として違反になる',
          en: 'In principle, it is a violation',
          zh: '原则上属于违规',
          vi: 'Về nguyên tắc, đây là vi phạm',
          tl: 'Sa prinsipyo, ito ay paglabag',
          id: 'Pada prinsipnya, ini adalah pelanggaran',
          my: 'မူလမူအရ ချိုးဖောက်မှုဖြစ်သည်',
          ko: '원칙적으로 위반이 된다',
          fr: 'En principe, c\'est une infraction',
          it: 'In linea di principio, è una violazione',
          pt: 'Em princípio, é uma infração'
        },
        correct: true
      },
      {
        text: {
          ja: 'ゆっくり走れば問題ない',
          en: 'No problem if you ride slowly',
          zh: '慢慢骑就没问题',
          vi: 'Không sao nếu đi chậm',
          tl: 'Walang problema kung mabagal ang takbo',
          id: 'Tidak masalah jika bersepeda pelan',
          my: 'နှေးနှေး မောင်းလျှင် ပြဿနာမရှိ',
          ko: '천천히 달리면 문제없다',
          fr: 'Pas de problème si vous roulez lentement',
          it: 'Nessun problema se si pedala lentamente',
          pt: 'Sem problema se andar devagar'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '自転車の二人乗りは原則として違反です（安全運転義務違反）。ただし、幼児用座席に6歳未満の子どもを乗せる場合や、特別に認められた自転車（タンデム自転車など）は例外です。転倒すると2人とも大けがをする危険があります。',
      en: 'Carrying a passenger on a bicycle is, in principle, a violation (safe-driving obligation). Exceptions include placing a child under 6 in an infant seat, or using a specially approved tandem bicycle. Both riders risk serious injury in a fall.',
      zh: '原则上，自行车两人乘坐属于违规（违反安全驾驶义务）。但例外情况包括：将6岁以下幼儿安置于儿童座椅，或使用特别认可的自行车（如双人自行车）。摔倒时两人都可能受重伤。',
      vi: 'Về nguyên tắc, chở người trên xe đạp là vi phạm (vi phạm nghĩa vụ lái xe an toàn). Ngoại lệ bao gồm việc đặt trẻ dưới 6 tuổi vào ghế trẻ em, hoặc sử dụng xe đạp đôi được phép. Cả hai người đều có nguy cơ bị thương nặng khi té ngã.',
      tl: 'Ang pagdadala ng pasahero sa bisikleta ay, sa prinsipyo, paglabag (safe-driving obligation). Kasama sa mga pagbubukod ang paglalagay ng batang wala pang 6 sa infant seat, o paggamit ng espesyal na awtorisadong tandem bicycle. Parehong maaaring matamaan nang malubha sa isang pagkahulog.',
      id: 'Membawa penumpang di sepeda pada prinsipnya adalah pelanggaran (kewajiban berkendara aman). Pengecualiannya adalah menempatkan anak di bawah 6 tahun di kursi bayi, atau menggunakan sepeda tandem yang disetujui khusus. Keduanya berisiko cedera serius jika jatuh.',
      my: 'မူလမူအရ၊ စက်ဘီးတွင် ခရီးသည် တင်ခြင်းသည် ချိုးဖောက်မှု (လုံခြုံသောမောင်းနှင်မှု တာဝန်ဝတ္တရားချိုးဖောက်ခြင်း) ဖြစ်သည်။ ၆ နှစ်မပြည့်သေးသော ကလေးကို ကလေးထိုင်ခုံတွင် ထိုင်ခိုင်းခြင်း သို့မဟုတ် ထူးခြားစွာ ခွင့်ပြုထားသော ဆိုင်ကယ် (tandem bicycle) သုံးခြင်း သည် ချွင်းချက်ဖြစ်သည်။',
      ko: '자전거 두 명 탑승은 원칙적으로 위반입니다（안전 운전 의무 위반）. 단, 6세 미만의 어린이를 유아용 좌석에 태우는 경우나, 특별히 인정된 자전거（탠덤 자전거 등）는 예외입니다. 넘어지면 두 사람 모두 크게 다칠 위험이 있습니다.',
      fr: 'Transporter un passager sur un vélo est, en principe, une infraction (violation de l\'obligation de conduite sécurisée). Les exceptions incluent le placement d\'un enfant de moins de 6 ans dans un siège pour enfant ou l\'utilisation d\'un tandem homologué. Les deux passagers risquent de se blesser gravement en cas de chute.',
      it: 'Trasportare un passeggero in bicicletta è, in linea di principio, una violazione (violazione dell\'obbligo di guida sicura). Le eccezioni includono il posizionamento di un bambino sotto i 6 anni in un seggiolino per bambini o l\'uso di un tandem approvato. Entrambi i ciclisti rischiano gravi lesioni in caso di caduta.',
      pt: 'Transportar um passageiro na bicicleta é, em princípio, uma infração (violação da obrigação de condução segura). As exceções incluem colocar uma criança com menos de 6 anos em um assento infantil ou usar uma bicicleta tandem especialmente aprovada. Ambos os passageiros correm risco de ferimentos graves em caso de queda.'
    },
    fineAmount: '3,000',
    criminal: false
  },

  /* ===== Q7: 信号無視（赤信号） ===== */
  {
    id: 7,
    question: {
      ja: '赤信号で止まろうとしたとき「自転車だから少しくらい…」と思い、そのまま進んだ。これは？',
      en: 'At a red light, you thought "It\'s just a bicycle, a little bit is fine…" and proceeded. What is this?',
      zh: '红灯时想"反正是自行车，差不多吧……"就直接通过了。这是？',
      vi: 'Khi đèn đỏ, bạn nghĩ "Chỉ là xe đạp thôi, một chút cũng được…" rồi tiếp tục đi. Đây là gì?',
      tl: 'Sa pulang ilaw, naisip mo "Bisikleta lang naman, kaunti lang…" at nagpatuloy ka. Ano ito?',
      id: 'Saat lampu merah, Anda berpikir "Hanya sepeda, sedikit saja tidak apa…" dan terus melaju. Apa ini?',
      my: 'အနီရောင် မီးတွင် "စက်ဘီးသာမို့ နည်းနည်းလောက်…" ဟုထင်ကာ ဆက်မောင်းသည်။ ဤသည်မှာ?',
      ko: '빨간 신호에서 멈추려 할 때 "자전거니까 조금쯤…"이라고 생각하고 그대로 나아갔습니다. 이것은?',
      fr: 'À un feu rouge, vous avez pensé « C\'est juste un vélo, un peu c\'est bien… » et avez continué. Qu\'est-ce que c\'est ?',
      it: 'A un semaforo rosso, hai pensato "È solo una bicicletta, un po\' di più va bene…" e sei andato avanti. Cos\'è questo?',
      pt: 'No sinal vermelho, você pensou "É só uma bicicleta, um pouco tudo bem…" e continuou. O que é isso?'
    },
    signImage: 'img/kiken07.png',
    category: '信号無視',
    choices: [
      {
        text: {
          ja: '自転車は信号に従わなくてよい',
          en: 'Bicycles do not need to obey traffic signals',
          zh: '自行车不需要遵守信号灯',
          vi: 'Xe đạp không cần tuân thủ đèn giao thông',
          tl: 'Hindi kailangang sundin ng bisikleta ang traffic signal',
          id: 'Sepeda tidak perlu mematuhi lampu lalu lintas',
          my: 'စက်ဘီးသည် မီးပြိုင့်ကို လိုက်နာရန် မလိုအပ်',
          ko: '자전거는 신호를 따르지 않아도 된다',
          fr: 'Les vélos n\'ont pas besoin d\'obéir aux feux de signalisation',
          it: 'Le biciclette non devono rispettare i semafori',
          pt: 'Bicicletas não precisam obedecer aos semáforos'
        },
        correct: false
      },
      {
        text: {
          ja: '歩行者信号に従えばよい',
          en: 'Following the pedestrian signal is sufficient',
          zh: '遵守行人信号就行',
          vi: 'Tuân theo đèn tín hiệu dành cho người đi bộ là đủ',
          tl: 'Sapat na ang pagsunod sa pedestrian signal',
          id: 'Cukup mengikuti sinyal pejalan kaki',
          my: 'လမ်းလျှောက်သူ မီးတစ်ခုကိုသာ လိုက်နာလျှင် လုံလောက်သည်',
          ko: '보행자 신호를 따르면 된다',
          fr: 'Il suffit de suivre le signal pour piétons',
          it: 'È sufficiente seguire il segnale pedonale',
          pt: 'Basta seguir o sinal para pedestres'
        },
        correct: false
      },
      {
        text: {
          ja: '信号無視の違反、青切符の対象',
          en: 'Signal violation — subject to a blue ticket',
          zh: '闯红灯违规，将被开蓝色罚单',
          vi: 'Vi phạm đèn tín hiệu — bị phạt phiếu xanh',
          tl: 'Paglabag sa signal — sakop ng blue ticket',
          id: 'Pelanggaran lampu lalu lintas — dikenai blue ticket',
          my: 'မီးပြိုင့် ချိုးဖောက်မှု — ဒဏ်ကြေး ပေးရနိုင်သည်',
          ko: '신호 무시 위반, 파란 딱지의 대상',
          fr: 'Infraction au signal — passible d\'un ticket bleu',
          it: 'Violazione del segnale — soggetto a ticket blu',
          pt: 'Infração de sinal — sujeito a ticket azul'
        },
        correct: true
      },
      {
        text: {
          ja: '車が来ていなければ問題ない',
          en: 'No problem if no cars are coming',
          zh: '没有车来的话没问题',
          vi: 'Không sao nếu không có xe đang đến',
          tl: 'Walang problema kung walang sasakyang darating',
          id: 'Tidak masalah jika tidak ada kendaraan yang datang',
          my: 'ကား မရောက်သေးလျှင် ပြဿနာမရှိ',
          ko: '차가 오지 않으면 문제없다',
          fr: 'Pas de problème si aucune voiture ne vient',
          it: 'Nessun problema se non arrivano auto',
          pt: 'Sem problema se não vierem carros'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '自転車も信号機に従う義務があります。赤信号を無視して進むのは信号無視の違反です。2026年5月施行の改正道路交通法で自転車にも青切符が交付されます。',
      en: 'Bicycles are obligated to obey traffic signals. Running a red light is a signal violation. Under the revised Road Traffic Law effective May 2026, bicycles can also receive a blue ticket.',
      zh: '自行车也有遵守交通信号的义务。闯红灯属于信号违规。依据2026年5月实施的修订道路交通法，自行车也将收到蓝色罚单。',
      vi: 'Xe đạp cũng có nghĩa vụ tuân thủ đèn giao thông. Vượt đèn đỏ là vi phạm tín hiệu. Theo Luật Giao thông sửa đổi có hiệu lực tháng 5/2026, xe đạp cũng có thể nhận phiếu phạt xanh.',
      tl: 'Ang mga bisikleta ay obligadong sumunod sa mga traffic signal. Ang paglampas ng pulang ilaw ay paglabag sa signal. Sa ilalim ng binagong Road Traffic Law na epektibo Mayo 2026, maaari ring makatanggap ng blue ticket ang bisikleta.',
      id: 'Sepeda juga wajib mematuhi lampu lalu lintas. Menerobos lampu merah adalah pelanggaran sinyal. Berdasarkan revisi UU Lalu Lintas Mei 2026, sepeda pun bisa mendapat blue ticket.',
      my: 'စက်ဘီးများသည်လည်း မီးပြိုင့်ကို လိုက်နာရန် တာဝန်ရှိသည်။ အနီရောင်မီးကို ဖြတ်ကျော်ခြင်းသည် မီးပြိုင့် ချိုးဖောက်မှု ဖြစ်သည်။ ၂၀၂၆ ခုနှစ် မေလတွင် ပြင်ဆင်ထားသော လမ်းအသွားအလာ ဥပဒေ အသက်ဝင်ပြီး စက်ဘီးများကိုလည်း ဒဏ်ပေးနိုင်သည်။',
      ko: '자전거도 신호기에 따를 의무가 있습니다. 빨간 신호를 무시하고 나아가는 것은 신호 무시 위반입니다. 2026년 5월 시행된 개정 도로교통법으로 자전거에도 파란 딱지가 발부됩니다.',
      fr: 'Les vélos sont obligés de respecter les feux de signalisation. Griller un feu rouge constitue une infraction au signal. En vertu de la loi révisée sur la circulation routière en vigueur en mai 2026, les vélos peuvent également recevoir un ticket bleu.',
      it: 'Anche le biciclette sono obbligate a rispettare i semafori. Passare con il rosso è una violazione del segnale. In base alla revisione del Codice della Strada in vigore da maggio 2026, anche le biciclette possono ricevere un ticket blu.',
      pt: 'As bicicletas são obrigadas a obedecer aos semáforos. Passar no sinal vermelho é uma infração de sinal. De acordo com a revisão da Lei de Trânsito em vigor a partir de maio de 2026, as bicicletas também podem receber um ticket azul.'
    },
    fineAmount: '6,000',
    criminal: false
  },

  /* ===== Q8: 一時不停止（止まれ標識） ===== */
  {
    id: 8,
    question: {
      ja: '「止まれ（一時停止）」の標識のある交差点で、左右を見ながらゆっくり通過した。問題は？',
      en: 'At an intersection marked "STOP," you looked left and right and passed through slowly. Is there a problem?',
      zh: '在有"停止（临时停车）"标志的路口，一边左右张望一边缓慢通过。有问题吗？',
      vi: 'Tại ngã tư có biển "DỪNG LẠI," bạn nhìn sang hai bên và đi qua từ từ. Có vấn đề không?',
      tl: 'Sa isang interseksyon na may karatulang "STOP," tumingin ka sa kaliwa at kanan at dahan-dahang lumipas. Mayroon bang problema?',
      id: 'Di persimpangan bertanda "STOP," Anda melihat kiri-kanan dan melintas perlahan. Ada masalah?',
      my: '"STOP" ဆိုင်းဘုတ်ရှိသော လမ်းဆုံတွင် ဘယ်ညာ ကြည့်ကာ နှေးနှေး ဖြတ်သည်။ ပြဿနာရှိသလား?',
      ko: '"멈춤（일시 정지）" 표지가 있는 교차로에서 좌우를 보면서 천천히 통과했습니다. 문제는?',
      fr: 'À un carrefour signalé « STOP », vous avez regardé à gauche et à droite et êtes passé lentement. Y a-t-il un problème ?',
      it: 'A un incrocio segnalato "STOP", hai guardato a sinistra e a destra e sei passato lentamente. C\'è un problema?',
      pt: 'Em um cruzamento com sinalização "PARE", você olhou para os lados e passou devagar. Há um problema?'
    },
    signImage: 'img/kiken08.png',
    category: '一時不停止',
    choices: [
      {
        text: {
          ja: '徐行したから問題ない',
          en: 'No problem because you slowed down',
          zh: '减速了就没问题',
          vi: 'Không sao vì đã giảm tốc',
          tl: 'Walang problema dahil bumagal ka',
          id: 'Tidak masalah karena sudah memperlambat',
          my: 'နှေးချလိုက်သောကြောင့် ပြဿနာမရှိ',
          ko: '서행했으니 문제없다',
          fr: 'Pas de problème car vous avez ralenti',
          it: 'Nessun problema perché hai rallentato',
          pt: 'Sem problema porque você reduziu a velocidade'
        },
        correct: false
      },
      {
        text: {
          ja: '車輪が止まらなければ一時不停止の違反',
          en: 'If the wheels do not stop completely, it is a failure-to-stop violation',
          zh: '车轮不完全停止则属于临时停车违规',
          vi: 'Nếu bánh xe không dừng hoàn toàn, đó là vi phạm không dừng',
          tl: 'Kung hindi tumitigil ang gulong, ito ay paglabag sa pagtigil',
          id: 'Jika roda tidak berhenti sepenuhnya, itu adalah pelanggaran tidak berhenti',
          my: ' bánh xe ဘီးများ လုံးဝ ရပ်မနေလျှင် ရပ်ရန်ပျက်ကွက်မှု ချိုးဖောက်မှု ဖြစ်သည်',
          ko: '바퀴가 멈추지 않으면 일시 불정지 위반',
          fr: 'Si les roues ne s\'arrêtent pas complètement, c\'est une infraction de non-arrêt',
          it: 'Se le ruote non si fermano completamente, è una violazione di mancato stop',
          pt: 'Se as rodas não pararem completamente, é uma infração de não parar'
        },
        correct: true
      },
      {
        text: {
          ja: '自転車は止まれ標識に従わなくてよい',
          en: 'Bicycles do not need to follow STOP signs',
          zh: '自行车不需要遵守停止标志',
          vi: 'Xe đạp không cần tuân theo biển DỪNG LẠI',
          tl: 'Hindi kailangang sumunod ng bisikleta sa STOP sign',
          id: 'Sepeda tidak perlu mengikuti rambu STOP',
          my: 'စက်ဘီးသည် STOP ဆိုင်းဘုတ်ကို လိုက်နာရန် မလိုအပ်',
          ko: '자전거는 멈춤 표지에 따르지 않아도 된다',
          fr: 'Les vélos n\'ont pas besoin de respecter les panneaux STOP',
          it: 'Le biciclette non devono rispettare i cartelli STOP',
          pt: 'Bicicletas não precisam seguir placas de PARE'
        },
        correct: false
      },
      {
        text: {
          ja: '左右確認すれば一時停止しなくてよい',
          en: 'Checking left and right means you do not need to stop',
          zh: '确认左右就不需要临时停车',
          vi: 'Nhìn trái phải thì không cần dừng',
          tl: 'Kung nagsuri ng kaliwa at kanan ay hindi na kailangang huminto',
          id: 'Melihat kiri-kanan berarti tidak perlu berhenti',
          my: 'ဘယ်ညာ စစ်ဆေးလျှင် ရပ်ရန် မလိုအပ်',
          ko: '좌우 확인을 하면 일시 정지를 안 해도 된다',
          fr: 'Regarder à gauche et à droite dispense de s\'arrêter',
          it: 'Controllare sinistra e destra non obbliga ad arrestarsi',
          pt: 'Verificar à esquerda e à direita significa que não é necessário parar'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '「止まれ」標識では、車輪が完全に止まるまで一時停止しなければなりません。「ゆっくり通過」「徐行」では違反になります。2026年5月施行の改正道路交通法で青切符の対象です。',
      en: 'At a STOP sign, you must come to a complete stop — wheels fully stopped. Merely slowing down is a violation. This is subject to a blue ticket under the revised Road Traffic Law effective May 2026.',
      zh: '遇"停止"标志，必须完全停车，直到车轮完全静止。"缓慢通过"或"减速"均属违规。依据2026年5月实施的修订道路交通法，将被开具蓝色罚单。',
      vi: 'Tại biển DỪNG LẠI, bạn phải dừng hoàn toàn — bánh xe không còn chuyển động. Chỉ giảm tốc là vi phạm. Điều này bị phạt phiếu xanh theo Luật Giao thông sửa đổi có hiệu lực tháng 5/2026.',
      tl: 'Sa isang STOP sign, kailangan mong huminto nang ganap — mga gulong na ganap na tumitigil. Ang pagbagal lamang ay paglabag. Sakop ito ng blue ticket sa ilalim ng binagong Road Traffic Law na epektibo Mayo 2026.',
      id: 'Di rambu STOP, Anda harus berhenti sepenuhnya — roda berhenti total. Sekadar memperlambat adalah pelanggaran. Ini dikenai blue ticket berdasarkan revisi UU Lalu Lintas Mei 2026.',
      my: 'STOP ဆိုင်းဘုတ်တွင် ဘီးများ လုံးဝ ရပ်သည်အထိ လုံးဝ ရပ်ရမည်ဖြစ်သည်။ နှေးချရုံဖြင့် ဖြတ်ကျော်ခြင်းသည် ချိုးဖောက်မှု ဖြစ်သည်။ ၂၀၂၆ ခုနှစ် မေလ ပြင်ဆင်ထားသော ဥပဒေ အသက်ဝင်ပြီး ဒဏ်ပေးနိုင်သည်။',
      ko: '"멈춤" 표지에서는 바퀴가 완전히 멈출 때까지 일시 정지를 해야 합니다. "천천히 통과"나 "서행"으로는 위반이 됩니다. 2026년 5월 시행된 개정 도로교통법으로 파란 딱지의 대상입니다.',
      fr: 'À un panneau STOP, vous devez vous arrêter complètement — roues totalement immobilisées. Simplement ralentir est une infraction. Cela est passible d\'un ticket bleu en vertu de la loi révisée sur la circulation routière en vigueur en mai 2026.',
      it: 'A un segnale di STOP, è obbligatorio fermarsi completamente — ruote completamente ferme. Rallentare soltanto è una violazione. Questo è soggetto a ticket blu in base alla revisione del Codice della Strada in vigore da maggio 2026.',
      pt: 'Em um sinal de PARE, você deve parar completamente — rodas totalmente paradas. Apenas desacelerar é uma infração. Isso está sujeito a ticket azul conforme a revisão da Lei de Trânsito em vigor a partir de maio de 2026.'
    },
    fineAmount: '5,000',
    criminal: false
  },

  /* ===== Q9: 信号無視（黄色） ===== */
  {
    id: 9,
    question: {
      ja: '黄色信号になったとき「急いで渡り切ろう」と加速して交差点に進入した。これは？',
      en: 'When the signal turned yellow, you sped up thinking "I will rush across" and entered the intersection. What is this?',
      zh: '信号变黄时，想着"赶紧冲过去"而加速进入路口。这是？',
      vi: 'Khi đèn chuyển vàng, bạn tăng tốc nghĩ "Cố vượt nhanh qua" và vào ngã tư. Đây là gì?',
      tl: 'Nang mag-yellow ang signal, pinabilis mo ang takbo na nag-iisip na "Mabilis na makatawid" at pumasok sa interseksyon. Ano ito?',
      id: 'Ketika lampu berubah kuning, Anda mempercepat sambil berpikir "Cepat lewat" dan memasuki persimpangan. Apa ini?',
      my: 'မီးဝါရောင်သို့ ပြောင်းသောအခါ "လျင်မြန်စွာ ကူးမည်" ဟုထင်ကာ ချဲ့ကာ လမ်းဆုံသို့ ဝင်သည်။ ဤသည်မှာ?',
      ko: '노란 신호가 되었을 때 "빨리 건너자"라고 생각해 가속하여 교차로로 진입했습니다. 이것은?',
      fr: 'Quand le signal est passé au jaune, vous avez accéléré en pensant « Je vais passer en vitesse » et avez abordé le carrefour. Qu\'est-ce que c\'est ?',
      it: 'Quando il segnale è diventato giallo, hai accelerato pensando "Passerò velocemente" e sei entrato nell\'incrocio. Cos\'è questo?',
      pt: 'Quando o sinal ficou amarelo, você acelerou pensando "Vou passar rápido" e entrou no cruzamento. O que é isso?'
    },
    signImage: 'img/kiken09.png',
    category: '信号無視',
    choices: [
      {
        text: {
          ja: '黄色は「注意して進め」なので問題ない',
          en: 'Yellow means "proceed with caution," so no problem',
          zh: '黄色意思是"注意前进"，所以没问题',
          vi: 'Vàng có nghĩa là "cẩn thận tiến", nên không sao',
          tl: 'Ang dilaw ay "magpatuloy nang maingat," kaya walang problema',
          id: 'Kuning berarti "lanjut dengan hati-hati," jadi tidak masalah',
          my: 'ဝါရောင်ဆိုသည်မှာ "သတိထားကာ ဆက်မောင်းပါ" ဟု အဓိပ္ပာယ်ရသောကြောင့် ပြဿနာမရှိ',
          ko: '노란 신호는 "주의해서 나아가라"이므로 문제없다',
          fr: 'Le jaune signifie « avancer avec prudence », donc pas de problème',
          it: 'Il giallo significa "procedere con cautela", quindi nessun problema',
          pt: 'Amarelo significa "avançar com cuidado", então sem problema'
        },
        correct: false
      },
      {
        text: {
          ja: '交差点手前で止まれる場合は停止が原則',
          en: 'If you can safely stop before the intersection, stopping is the rule',
          zh: '如果在路口前能安全停车，停车是原则',
          vi: 'Nếu có thể dừng an toàn trước ngã tư, việc dừng lại là nguyên tắc',
          tl: 'Kung maaaring ligtas na huminto bago ang interseksyon, ang pagtigil ang panuntunan',
          id: 'Jika bisa berhenti aman sebelum persimpangan, berhenti adalah aturannya',
          my: 'လမ်းဆုံမတိုင်မီ လုံခြုံစွာ ရပ်နိုင်လျှင် ရပ်ခြင်းသည် မူဝါဒဖြစ်သည်',
          ko: '교차로 앞에서 멈출 수 있는 경우는 정지가 원칙',
          fr: 'Si vous pouvez vous arrêter en sécurité avant le carrefour, s\'arrêter est la règle',
          it: 'Se si può fermarsi in sicurezza prima dell\'incrocio, fermarsi è la regola',
          pt: 'Se você puder parar com segurança antes do cruzamento, parar é a regra'
        },
        correct: true
      },
      {
        text: {
          ja: '速度を上げれば問題ない',
          en: 'No problem if you speed up to clear the intersection',
          zh: '加速通过就没问题',
          vi: 'Không sao nếu tăng tốc để qua ngã tư',
          tl: 'Walang problema kung mapabilis ang takbo para makalayo sa interseksyon',
          id: 'Tidak masalah jika mempercepat untuk melewati persimpangan',
          my: 'လမ်းဆုံကို ပိုမြန်မြန် ဖြတ်နိုင်ရန် ချဲ့ကာ မောင်းလျှင် ပြဿနာမရှိ',
          ko: '속도를 높이면 문제없다',
          fr: 'Pas de problème si vous accélérez pour dégager le carrefour',
          it: 'Nessun problema se si accelera per superare l\'incrocio',
          pt: 'Sem problema se acelerar para liberar o cruzamento'
        },
        correct: false
      },
      {
        text: {
          ja: '自転車は黄信号を無視できる',
          en: 'Bicycles can ignore yellow signals',
          zh: '自行车可以无视黄灯',
          vi: 'Xe đạp có thể bỏ qua đèn vàng',
          tl: 'Maaaring balewalain ng bisikleta ang yellow signal',
          id: 'Sepeda bisa mengabaikan lampu kuning',
          my: 'စက်ဘီးသည် ဝါရောင်မီးကို လျစ်လျူရှုနိုင်သည်',
          ko: '자전거는 노란 신호를 무시할 수 있다',
          fr: 'Les vélos peuvent ignorer les signaux jaunes',
          it: 'Le biciclette possono ignorare i segnali gialli',
          pt: 'Bicicletas podem ignorar sinais amarelos'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '黄色信号は「止まれ（停止できる場合）」を意味します。交差点手前で安全に停止できるなら止まるのが原則で、加速して進入するのは信号無視に準じた危険行為です。自転車も信号機の規則に従わなければなりません。',
      en: 'A yellow signal means "stop if you safely can." If you can stop safely before the intersection, you must do so. Speeding up to enter is a dangerous act equivalent to a signal violation. Bicycles must follow traffic signal rules.',
      zh: '黄色信号意味着"停车（如果能停下来的话）"。如果能在路口前安全停车，原则上应该停车。加速进入路口是危险行为，相当于信号违规。自行车同样须遵守交通信号规则。',
      vi: 'Đèn vàng có nghĩa là "dừng lại nếu có thể dừng an toàn." Nếu có thể dừng an toàn trước ngã tư, bạn phải dừng. Tăng tốc để vào ngã tư là hành vi nguy hiểm tương đương vi phạm tín hiệu. Xe đạp cũng phải tuân theo quy tắc đèn giao thông.',
      tl: 'Ang yellow signal ay nangangahulugang "huminto kung maaari mong ligtas na gawin." Kung kaya mong ligtas na huminto bago ang interseksyon, dapat mo itong gawin. Ang pagbilis para pumasok ay isang mapanganib na kilos na katumbas ng paglabag sa signal. Ang mga bisikleta ay dapat din sumunod sa mga panuntunan ng traffic signal.',
      id: 'Lampu kuning berarti "berhenti jika bisa berhenti aman." Jika bisa berhenti aman sebelum persimpangan, Anda harus berhenti. Mempercepat untuk masuk adalah tindakan berbahaya setara pelanggaran sinyal. Sepeda juga harus mengikuti aturan lampu lalu lintas.',
      my: 'ဝါရောင်မီးဆိုသည်မှာ "လုံခြုံစွာ ရပ်နိုင်လျှင် ရပ်ပါ" ဟု အဓိပ္ပာယ်ရသည်။ လမ်းဆုံမတိုင်မီ လုံခြုံစွာ ရပ်နိုင်လျှင် ရပ်ရမည်ဖြစ်သည်။ ချဲ့ကာ ဝင်ခြင်းသည် မီးပြိုင့် ချိုးဖောက်မှုနှင့် ညီမျှသော အန္တရာယ်ရှိသော လုပ်ရပ်ဖြစ်သည်။',
      ko: '노란 신호는 "멈춤（멈출 수 있는 경우）"을 의미합니다. 교차로 앞에서 안전하게 멈출 수 있다면 멈추는 것이 원칙이며, 가속하여 진입하는 것은 신호 위반에 준하는 위험 행위입니다. 자전거도 신호기 규칙을 따라야 합니다.',
      fr: 'Un signal jaune signifie « s\'arrêter si vous le pouvez en sécurité ». Si vous pouvez vous arrêter en toute sécurité avant le carrefour, vous devez le faire. Accélérer pour entrer est un acte dangereux équivalent à une infraction au signal. Les vélos doivent respecter les règles des feux de signalisation.',
      it: 'Un segnale giallo significa "fermarsi se si può fare in sicurezza". Se ci si può fermare in sicurezza prima dell\'incrocio, è obbligatorio farlo. Accelerare per entrare è un atto pericoloso equivalente a una violazione del segnale. Le biciclette devono rispettare le norme dei semafori.',
      pt: 'Um sinal amarelo significa "parar se puder com segurança". Se você puder parar com segurança antes do cruzamento, deve fazê-lo. Acelerar para entrar é um ato perigoso equivalente a uma infração de sinal. As bicicletas devem seguir as regras dos semáforos.'
    },
    fineAmount: '6,000',
    criminal: false
  },

  /* ===== Q10: 一時不停止（踏切） ===== */
  {
    id: 10,
    question: {
      ja: '踏切の前に「止まれ」の標示がありました。自転車はどうすべきですか？',
      en: 'There is a "STOP" marking before a railroad crossing. What should a cyclist do?',
      zh: '铁路道口前有"停止"标志。自行车应该怎么做？',
      vi: 'Có biển "DỪNG LẠI" trước đường sắt. Người đi xe đạp nên làm gì?',
      tl: 'Mayroong "STOP" na marka bago ang isang riles ng tren. Ano ang dapat gawin ng nagbibisikleta?',
      id: 'Ada tanda "STOP" sebelum perlintasan rel kereta. Apa yang harus dilakukan oleh pesepeda?',
      my: 'မီးရထားလမ်း ဖြတ်ကျော်ရာ မတိုင်မီ "STOP" သင်္ကေတ ရှိသည်။ စက်ဘီးသမားမည်သို့ ပြုမူသင့်သနည်း?',
      ko: '건널목 앞에 "멈춤" 표시가 있었습니다. 자전거는 어떻게 해야 합니까?',
      fr: 'Il y a un marquage « STOP » avant un passage à niveau. Que doit faire un cycliste ?',
      it: 'C\'è un segnale di "STOP" prima di un passaggio a livello. Cosa deve fare un ciclista?',
      pt: 'Há uma marcação de "PARE" antes de um cruzamento ferroviário. O que deve fazer um ciclista?'
    },
    signImage: 'img/kiken10.png',
    category: '一時不停止',
    choices: [
      {
        text: {
          ja: '電車が来ていなければ止まらなくてよい',
          en: 'No need to stop if no train is coming',
          zh: '没有火车来的话不需要停',
          vi: 'Không cần dừng nếu không có tàu đến',
          tl: 'Hindi na kailangang huminto kung walang darating na tren',
          id: 'Tidak perlu berhenti jika tidak ada kereta yang datang',
          my: 'မီးရထား မရောက်သေးလျှင် ရပ်ရန် မလိုအပ်',
          ko: '기차가 오지 않으면 멈추지 않아도 된다',
          fr: 'Pas besoin de s\'arrêter si aucun train ne vient',
          it: 'Non è necessario fermarsi se non arriva nessun treno',
          pt: 'Não é necessário parar se nenhum trem estiver vindo'
        },
        correct: false
      },
      {
        text: {
          ja: '遮断機が上がっていれば止まらなくてよい',
          en: 'No need to stop if the barrier is raised',
          zh: '拦截杆升起来的话不需要停',
          vi: 'Không cần dừng nếu thanh chắn được nâng lên',
          tl: 'Hindi na kailangang huminto kung nakataas ang barrier',
          id: 'Tidak perlu berhenti jika palang terbuka',
          my: 'တားဆီးကန့်လန့်တန်း မြှောက်ထားလျှင် ရပ်ရန် မလိုအပ်',
          ko: '차단기가 올라가 있으면 멈추지 않아도 된다',
          fr: 'Pas besoin de s\'arrêter si la barrière est levée',
          it: 'Non è necessario fermarsi se la barriera è alzata',
          pt: 'Não é necessário parar se a barreira estiver levantada'
        },
        correct: false
      },
      {
        text: {
          ja: '必ず一時停止して左右を確認してから通過',
          en: 'Always come to a complete stop, check both directions, then cross',
          zh: '必须完全停车，左右确认后再通过',
          vi: 'Luôn dừng hoàn toàn, kiểm tra cả hai phía rồi mới qua',
          tl: 'Laging ganap na huminto, suriin ang magkabilang panig, pagkatapos ay tumawid',
          id: 'Selalu berhenti penuh, cek kedua arah, baru melintas',
          my: 'အမြဲ လုံးဝ ရပ်ပြီး ဘယ်ညာ စစ်ဆေးကာ ဖြတ်ကျော်ပါ',
          ko: '반드시 일시 정지하여 좌우를 확인하고 나서 통과',
          fr: 'S\'arrêter complètement, vérifier les deux sens, puis traverser',
          it: 'Fermarsi completamente, controllare in entrambe le direzioni, poi attraversare',
          pt: 'Sempre parar completamente, verificar em ambas as direções e depois cruzar'
        },
        correct: true
      },
      {
        text: {
          ja: '自転車は踏切に「止まれ」は適用されない',
          en: 'STOP rules do not apply to bicycles at railroad crossings',
          zh: '自行车不受道口"停止"规则约束',
          vi: 'Quy tắc DỪNG LẠI không áp dụng cho xe đạp tại đường sắt',
          tl: 'Hindi naaangkop ang STOP rules sa mga bisikleta sa riles',
          id: 'Aturan STOP tidak berlaku untuk sepeda di perlintasan kereta',
          my: 'မီးရထားလမ်း ဖြတ်ကျော်ရာတွင် STOP စည်းကမ်း စက်ဘီးများအတွက် မသက်ဆိုင်',
          ko: '자전거는 건널목의 "멈춤"이 적용되지 않는다',
          fr: 'Les règles STOP ne s\'appliquent pas aux vélos aux passages à niveau',
          it: 'Le norme di STOP non si applicano alle biciclette ai passaggi a livello',
          pt: 'As regras de PARE não se aplicam a bicicletas em cruzamentos ferroviários'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '踏切では、電車の有無にかかわらず一時停止して安全を確認する義務があります（道路交通法第33条）。自転車も同様です。一時停止を怠ると踏切安全義務違反になります。',
      en: 'At a railroad crossing, you are required to stop completely and confirm safety regardless of whether a train is coming (Road Traffic Law Article 33). This applies to bicycles too. Failing to stop is a railroad crossing safety violation.',
      zh: '在铁路道口，无论有无火车，都必须临时停车确认安全（《道路交通法》第33条）。自行车同样适用。不停车将构成道口安全义务违反。',
      vi: 'Tại đường sắt, bạn phải dừng hoàn toàn và xác nhận sự an toàn bất kể có tàu hay không (Luật Giao thông Điều 33). Điều này cũng áp dụng cho xe đạp. Không dừng là vi phạm nghĩa vụ an toàn đường sắt.',
      tl: 'Sa pag-abot ng riles ng tren, kailangan mong huminto nang ganap at kumpirmahin ang kaligtasan anuman ang pagdating ng tren (Road Traffic Law Article 33). Naaangkop ito sa mga bisikleta. Ang hindi pagtigil ay paglabag sa kaligtasan ng riles.',
      id: 'Di perlintasan kereta, Anda wajib berhenti penuh dan memastikan keamanan terlepas dari apakah ada kereta atau tidak (UU Lalu Lintas Pasal 33). Ini juga berlaku untuk sepeda. Tidak berhenti adalah pelanggaran keselamatan perlintasan kereta.',
      my: 'မီးရထားလမ်း ဖြတ်ကျော်ရာတွင် မီးရထား ရောက်ရောက်မရောက်ရောက် လုံးဝ ရပ်ပြီး လုံခြုံမှု အတည်ပြုရမည် (လမ်းအသွားအလာ ဥပဒေ ပုဒ်မ ၃၃)။ ဤသည်သည် စက်ဘီးများကိုလည်း သက်ဆိုင်သည်။ မရပ်ပဲ ဖြတ်ကျော်ခြင်းသည် မီးရထားလမ်း ဖြတ်ကျော်ရာ လုံခြုံရေး ချိုးဖောက်မှု ဖြစ်သည်။',
      ko: '건널목에서는 기차의 유무와 관계없이 일시 정지하여 안전을 확인할 의무가 있습니다（도로교통법 제33조）. 자전거도 마찬가지입니다. 일시 정지를 게을리하면 건널목 안전 의무 위반이 됩니다.',
      fr: 'À un passage à niveau, vous êtes tenu de vous arrêter complètement et de vérifier la sécurité, qu\'un train arrive ou non (Code de la route, article 33). Cela s\'applique également aux vélos. Ne pas s\'arrêter constitue une violation des obligations de sécurité au passage à niveau.',
      it: 'A un passaggio a livello, siete obbligati a fermarvi completamente e a verificare la sicurezza indipendentemente dalla presenza di treni (Codice della Strada, articolo 33). Questo vale anche per le biciclette. Non fermarsi costituisce una violazione degli obblighi di sicurezza al passaggio a livello.',
      pt: 'Em um cruzamento ferroviário, você é obrigado a parar completamente e confirmar a segurança independentemente de um trem estar vindo (Lei de Trânsito, Artigo 33). Isso se aplica também às bicicletas. Não parar é uma violação das obrigações de segurança no cruzamento ferroviário.'
    },
    fineAmount: '5,000',
    criminal: false
  },

  /* ===== Q11: 逆走・右側通行（車道右側） ===== */
  {
    id: 11,
    question: {
      ja: '目的地が近いので、車道の右側（対向車線側）を自転車で走った。これは？',
      en: 'Since your destination is nearby, you rode on the right side of the road (oncoming lane side). What is this?',
      zh: '因为目的地近，在道路右侧（对向车道一侧）骑自行车。这是？',
      vi: 'Vì điểm đến gần, bạn đi trên làn phải của đường (phía làn ngược chiều). Đây là gì?',
      tl: 'Dahil malapit ang destinasyon, nagmaneho ka sa kanang bahagi ng kalsada (gilid ng oncoming lane). Ano ito?',
      id: 'Karena tujuan dekat, Anda bersepeda di sisi kanan jalan (sisi lajur berlawanan). Apa ini?',
      my: 'ရည်မှန်းချက် နီးသောကြောင့် လမ်းမ၏ ညာဘက် (ဆန့်ကျင်ဘက်ကား လမ်းကြောင်း) တွင် စက်ဘီး မောင်းသည်။ ဤသည်မှာ?',
      ko: '목적지가 가까워 차도의 오른쪽（대향차선 쪽）을 자전거로 달렸습니다. 이것은?',
      fr: 'Comme votre destination est proche, vous avez roulé sur le côté droit de la route (côté voie en sens inverse). Qu\'est-ce que c\'est ?',
      it: 'Poiché la destinazione è vicina, hai pedalato sul lato destro della strada (lato corsia opposta). Cos\'è questo?',
      pt: 'Como seu destino fica perto, você pedalou no lado direito da estrada (lado da faixa contrária). O que é isso?'
    },
    signImage: 'img/kiken11.png',
    category: '逆走・右側通行',
    choices: [
      {
        text: {
          ja: '自転車は右側でも走れる',
          en: 'Bicycles can also ride on the right side',
          zh: '自行车也可以靠右行驶',
          vi: 'Xe đạp cũng có thể đi ở bên phải',
          tl: 'Maaari ring sumakay ang bisikleta sa kanang bahagi',
          id: 'Sepeda juga bisa melaju di sisi kanan',
          my: 'စက်ဘီးသည် ညာဘက်တွင်လည်း မောင်းနင်းနိုင်သည်',
          ko: '자전거는 오른쪽도 달릴 수 있다',
          fr: 'Les vélos peuvent aussi rouler sur le côté droit',
          it: 'Anche le biciclette possono andare sul lato destro',
          pt: 'As bicicletas também podem andar no lado direito'
        },
        correct: false
      },
      {
        text: {
          ja: '右側通行（逆走）の違反',
          en: 'Wrong-way (right-side) riding — a violation',
          zh: '右侧通行（逆行）违规',
          vi: 'Vi phạm đi ngược chiều (bên phải)',
          tl: 'Paglabag sa wrong-way (kanang bahagi) na pagmamaneho',
          id: 'Pelanggaran berkendara di sisi kanan (melawan arus)',
          my: 'ညာဘက်မောင်း (လမ်းပြောင်းပြန်) ချိုးဖောက်မှု',
          ko: '우측 통행（역주행）의 위반',
          fr: 'Infraction pour conduite à contresens (côté droit)',
          it: 'Violazione per guida contromano (lato destro)',
          pt: 'Infração por condução na contramão (lado direito)'
        },
        correct: true
      },
      {
        text: {
          ja: '歩道が混んでいれば右側でもよい',
          en: 'Right side is fine if the sidewalk is crowded',
          zh: '人行道拥挤的话走右侧也行',
          vi: 'Được đi bên phải nếu vỉa hè đông đúc',
          tl: 'Okay ang kanang bahagi kung masikip ang sidewalk',
          id: 'Sisi kanan boleh jika trotoar penuh',
          my: 'လမ်းလျှောက်ကွင်း လူကြပ်ရှိလျှင် ညာဘက် ဖြစ်ပါသည်',
          ko: '인도가 막혀 있으면 오른쪽도 괜찮다',
          fr: 'Le côté droit est acceptable si le trottoir est encombré',
          it: 'Il lato destro va bene se il marciapiede è affollato',
          pt: 'O lado direito é aceitável se a calçada estiver lotada'
        },
        correct: false
      },
      {
        text: {
          ja: '夜間なら右側の方が安全',
          en: 'The right side is safer at night',
          zh: '夜间靠右更安全',
          vi: 'Bên phải an toàn hơn vào ban đêm',
          tl: 'Mas ligtas ang kanang bahagi sa gabi',
          id: 'Sisi kanan lebih aman di malam hari',
          my: 'ညဘက်ဆိုလျှင် ညာဘက်ပိုလုံခြုံသည်',
          ko: '야간에는 오른쪽이 더 안전하다',
          fr: 'Le côté droit est plus sûr la nuit',
          it: 'Il lato destro è più sicuro di notte',
          pt: 'O lado direito é mais seguro à noite'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '自転車は車道の左側を通行しなければなりません（道路交通法第17条・第18条）。右側通行（逆走）は、対向車との正面衝突事故を引き起こす非常に危険な行為です。2026年5月施行の改正道路交通法で青切符の対象です。',
      en: 'Bicycles must ride on the left side of the road (Road Traffic Law Articles 17 and 18). Wrong-way riding on the right side is extremely dangerous and can cause head-on collisions. It is subject to a blue ticket under the revised law effective May 2026.',
      zh: '自行车必须靠道路左侧行驶（《道路交通法》第17条、第18条）。靠右行驶（逆行）极为危险，可能引发与对向车辆的正面碰撞。依据2026年5月实施的修订道路交通法，将被开具蓝色罚单。',
      vi: 'Xe đạp phải đi ở bên trái đường (Luật Giao thông Điều 17 và 18). Đi sai làn đường (bên phải) cực kỳ nguy hiểm và có thể gây va chạm đối đầu. Bị phạt phiếu xanh theo luật sửa đổi có hiệu lực tháng 5/2026.',
      tl: 'Ang mga bisikleta ay dapat magtakbo sa kaliwang bahagi ng kalsada (Road Traffic Law Articles 17 at 18). Ang pagmamaneho sa maling direksiyon (kanang bahagi) ay lubhang mapanganib at maaaring magdulot ng head-on collision. Sakop ng blue ticket sa ilalim ng binagong batas na epektibo Mayo 2026.',
      id: 'Sepeda harus melaju di sisi kiri jalan (UU Lalu Lintas Pasal 17 dan 18). Berkendara di sisi kanan (melawan arus) sangat berbahaya dan bisa menyebabkan tabrakan frontal. Dikenai blue ticket berdasarkan revisi UU Mei 2026.',
      my: 'စက်ဘီးသည် လမ်းမ၏ ဘယ်ဘက်တွင် မောင်းရမည် (လမ်းအသွားအလာ ဥပဒေ ပုဒ်မ ၁၇ နှင့် ၁၈)။ ညာဘက်မောင်းခြင်း (လမ်းပြောင်းပြန်) သည် အလွန်အန္တရာယ်ရှိပြီး မျက်နှာချင်းဆိုင် တိုက်မှု ဖြစ်နိုင်သည်။',
      ko: '자전거는 차도의 왼쪽을 통행해야 합니다（도로교통법 제17조·제18조）. 우측 통행（역주행）은 대향차와의 정면 충돌 사고를 일으키는 매우 위험한 행위입니다. 2026년 5월 시행된 개정 도로교통법으로 파란 딱지의 대상입니다.',
      fr: 'Les vélos doivent rouler sur le côté gauche de la route (Code de la route, articles 17 et 18). Rouler à contresens sur le côté droit est extrêmement dangereux et peut provoquer des collisions frontales. C\'est passible d\'un ticket bleu en vertu de la loi révisée en vigueur en mai 2026.',
      it: 'Le biciclette devono andare sul lato sinistro della strada (Codice della Strada, articoli 17 e 18). Andare contromano sul lato destro è estremamente pericoloso e può causare collisioni frontali. È soggetto a ticket blu ai sensi della revisione del Codice della Strada in vigore da maggio 2026.',
      pt: 'As bicicletas devem andar no lado esquerdo da estrada (Lei de Trânsito, Artigos 17 e 18). Andar na contramão no lado direito é extremamente perigoso e pode causar colisões frontais. Está sujeito a ticket azul conforme a revisão da Lei de Trânsito em vigor a partir de maio de 2026.'
    },
    fineAmount: '5,000',
    criminal: false
  },

  /* ===== Q12: 一方通行逆走 ===== */
  {
    id: 12,
    question: {
      ja: '「一方通行」の標識がある道路を、自転車で逆方向に走った。標識には「自転車を除く」などの追加の表示はありません。これは違反ですか？',
      en: 'You cycled the wrong way on a one-way road. The sign has no "except bicycles" or similar note. Is this a violation?',
      zh: '在有"单行道"标志的道路上，骑自行车逆向行驶。标志上没有"自行车除外"等附加说明。这是违规吗？',
      vi: 'Bạn đi xe đạp ngược chiều trên đường một chiều. Biển hiệu không có ghi chú "trừ xe đạp." Đây có phải vi phạm không?',
      tl: 'Nagmaneho ka nang kabaligtaran sa isang one-way road. Walang "maliban sa bisikleta" sa karatula. Paglabag ba ito?',
      id: 'Anda bersepeda melawan arus di jalan satu arah. Rambu tidak ada keterangan "kecuali sepeda." Apakah ini pelanggaran?',
      my: 'တစ်ဦးတည်း လမ်းတွင် စက်ဘီး ဆန့်ကျင်ဘက် မောင်းသည်။ ဆိုင်းဘုတ်တွင် "စက်ဘီး မပါ" ဟု ထပ်ဖြည့်မထားပါ။ ဤသည် ချိုးဖောက်မှုလား?',
      ko: '"일방통행" 표지가 있는 도로를 자전거로 역방향으로 달렸습니다. 표지에는 "자전거 제외" 등의 추가 표시가 없습니다. 이것은 위반입니까?',
      fr: 'Vous avez roulé à contre-sens sur une route à sens unique. Le panneau ne comporte pas de note « sauf vélos ». Est-ce une infraction ?',
      it: 'Hai pedalato in senso contrario su una strada a senso unico. Il cartello non ha nessuna nota "tranne biciclette". È una violazione?',
      pt: 'Você pedalou na direção errada em uma rua de mão única. A placa não tem nota "exceto bicicletas". Isso é uma infração?'
    },
    signImage: 'img/kiken12.png',
    category: '逆走・右側通行',
    choices: [
      {
        text: {
          ja: '自転車は一方通行に関係ない',
          en: 'One-way rules do not apply to bicycles',
          zh: '单行道规则与自行车无关',
          vi: 'Quy tắc một chiều không áp dụng cho xe đạp',
          tl: 'Hindi naaangkop sa bisikleta ang one-way rules',
          id: 'Aturan satu arah tidak berlaku untuk sepeda',
          my: 'တစ်ဦးတည်းလမ်း စည်းကမ်းသည် စက်ဘီးနှင့် မဆိုင်',
          ko: '자전거는 일방통행과 관계없다',
          fr: 'Les règles de sens unique ne s\'appliquent pas aux vélos',
          it: 'Le norme del senso unico non si applicano alle biciclette',
          pt: 'As regras de mão única não se aplicam a bicicletas'
        },
        correct: false
      },
      {
        text: {
          ja: '補助標識がなければ逆走は違反',
          en: 'Without an exception sign, riding the wrong way is a violation',
          zh: '没有辅助标志的话，逆行属违规',
          vi: 'Nếu không có biển ngoại lệ, đi ngược chiều là vi phạm',
          tl: 'Kung walang exception sign, ang pagmamaneho sa maling direksyon ay paglabag',
          id: 'Tanpa tanda pengecualian, melawan arus adalah pelanggaran',
          my: 'ချွင်းချက် ဆိုင်းဘုတ် မရှိလျှင် ဆန့်ကျင်ဘက် မောင်းခြင်းသည် ချိုးဖောက်မှု',
          ko: '보조 표지가 없으면 역주행은 위반',
          fr: 'Sans panneau d\'exception, rouler à contresens est une infraction',
          it: 'Senza un cartello di eccezione, andare contromano è una violazione',
          pt: 'Sem placa de exceção, pedalar na direção errada é uma infração'
        },
        correct: true
      },
      {
        text: {
          ja: '一方通行は自動車だけに適用される',
          en: 'One-way rules apply only to automobiles',
          zh: '单行道规则只适用于汽车',
          vi: 'Quy tắc một chiều chỉ áp dụng cho ô tô',
          tl: 'Ang one-way rules ay para lang sa mga sasakyan',
          id: 'Aturan satu arah hanya berlaku untuk mobil',
          my: 'တစ်ဦးတည်းလမ်း စည်းကမ်းသည် ကားများအတွက်သာ သက်ဆိုင်သည်',
          ko: '일방통행은 자동차에만 적용된다',
          fr: 'Les règles de sens unique s\'appliquent uniquement aux automobiles',
          it: 'Le norme del senso unico si applicano solo alle automobili',
          pt: 'As regras de mão única se aplicam apenas a automóveis'
        },
        correct: false
      },
      {
        text: {
          ja: 'ゆっくり走れば逆走できる',
          en: 'You can go the wrong way if you ride slowly',
          zh: '慢慢骑的话可以逆行',
          vi: 'Có thể đi ngược chiều nếu đạp chậm',
          tl: 'Maaaring magmaneho sa maling direksyon kung mabagal ang takbo',
          id: 'Boleh melawan arus jika bersepeda pelan',
          my: 'နှေးနှေး မောင်းလျှင် ဆန့်ကျင်ဘက် မောင်းနင်းနိုင်သည်',
          ko: '천천히 달리면 역주행할 수 있다',
          fr: 'Vous pouvez aller à contresens si vous roulez lentement',
          it: 'Si può andare contromano se si pedala lentamente',
          pt: 'Você pode ir na contramão se andar devagar'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '一方通行の道路では、「自転車を除く」「軽車両を除く」などの補助標識がある場合に限り逆走が許可されます。補助標識がなければ自転車も一方通行に従う義務があります。無視すると交通違反（青切符）の対象です。',
      en: 'On a one-way road, riding against traffic is only permitted when a supplementary sign such as "except bicycles" is posted. Without such a sign, bicycles must follow the one-way rule. Ignoring it is subject to a blue ticket.',
      zh: '在单行道上，只有在有"自行车除外""轻车辆除外"等辅助标志时，才允许逆行。没有辅助标志时，自行车也必须遵守单行道规定。违反将被开具蓝色罚单。',
      vi: 'Trên đường một chiều, chỉ được phép đi ngược chiều khi có biển phụ như "trừ xe đạp." Nếu không có biển đó, xe đạp cũng phải tuân theo quy tắc một chiều. Vi phạm sẽ bị phạt phiếu xanh.',
      tl: 'Sa isang one-way road, ang pagmamaneho laban sa trapiko ay pinahihintulutan lamang kapag may karagdagang karatula tulad ng "maliban sa bisikleta." Kung wala, ang mga bisikleta ay dapat sumunod sa one-way rule. Ang paglabag ay sakop ng blue ticket.',
      id: 'Di jalan satu arah, melawan arus hanya diizinkan jika ada tanda tambahan seperti "kecuali sepeda." Tanpa tanda tersebut, sepeda juga wajib mengikuti aturan satu arah. Melanggar dikenai blue ticket.',
      my: 'တစ်ဦးတည်းလမ်းတွင် "စက်ဘီး မပါ" ကဲ့သို့ ထပ်ဖြည့်ဆိုင်းဘုတ် ရှိမှသာ ဆန့်ကျင်ဘက် မောင်းခွင့်ရှိသည်။ ထိုကဲ့သို့ ဆိုင်းဘုတ် မရှိလျှင် စက်ဘီးသည်လည်း တစ်ဦးတည်းလမ်း စည်းကမ်းကို လိုက်နာရမည်။',
      ko: '일방통행 도로에서는 "자전거 제외" 등의 보조 표지가 있는 경우에 한해 역주행이 허용됩니다. 보조 표지가 없으면 자전거도 일방통행을 따를 의무가 있습니다. 무시하면 교통 위반（파란 딱지）의 대상입니다.',
      fr: 'Sur une route à sens unique, rouler à contresens n\'est autorisé que lorsqu\'un panneau complémentaire tel que « sauf vélos » est affiché. Sans un tel panneau, les vélos doivent respecter la règle du sens unique. L\'enfreindre est passible d\'un ticket bleu.',
      it: 'Su una strada a senso unico, andare contromano è consentito solo se è presente un segnale supplementare come "tranne biciclette". Senza tale segnale, anche le biciclette devono rispettare la regola del senso unico. Ignorarla è soggetto a ticket blu.',
      pt: 'Em uma rua de mão única, pedalar na direção contrária só é permitido quando há uma placa suplementar como "exceto bicicletas". Sem essa placa, as bicicletas também devem seguir a regra de mão única. Ignorá-la está sujeito a ticket azul.'
    },
    fineAmount: '5,000',
    criminal: false
  },

  /* ===== Q13: 自転車専用レーン逆走 ===== */
  {
    id: 13,
    question: {
      ja: '自転車専用レーンが設けられた道路で、右側のレーンを使って走った。問題はありますか？',
      en: 'On a road with a bicycle lane, you used the lane on the right side. Is there a problem?',
      zh: '在设有自行车专用道的道路上，使用右侧车道行驶。有问题吗？',
      vi: 'Trên đường có làn dành riêng cho xe đạp, bạn đi trên làn bên phải. Có vấn đề không?',
      tl: 'Sa isang kalsada na may bicycle lane, gumamit ka ng lane sa kanang bahagi. Mayroon bang problema?',
      id: 'Di jalan yang memiliki jalur sepeda, Anda menggunakan jalur di sisi kanan. Ada masalah?',
      my: 'စက်ဘီး သီးသန့်လမ်းကြောင်း ရှိသော လမ်းမတွင် ညာဘက်လမ်းကြောင်းကို သုံး၍ မောင်းသည်။ ပြဿနာရှိသလား?',
      ko: '자전거 전용 차선이 설치된 도로에서 오른쪽 차선을 이용해 달렸습니다. 문제가 있습니까?',
      fr: 'Sur une route avec une piste cyclable, vous avez utilisé la voie du côté droit. Y a-t-il un problème ?',
      it: 'Su una strada con una corsia ciclabile, hai utilizzato la corsia sul lato destro. C\'è un problema?',
      pt: 'Em uma estrada com ciclofaixa, você usou a faixa do lado direito. Há um problema?'
    },
    signImage: 'img/kiken13.png',
    category: '逆走・右側通行',
    choices: [
      {
        text: {
          ja: '自転車専用レーンならどこでも走れる',
          en: 'You can ride anywhere in a bicycle lane',
          zh: '只要是自行车专用道就可以随便骑',
          vi: 'Bạn có thể đi bất cứ đâu trong làn xe đạp',
          tl: 'Maaaring sumakay kahit saan sa bicycle lane',
          id: 'Bisa melaju di mana saja di jalur sepeda',
          my: 'စက်ဘီး သီးသန့်လမ်းကြောင်း ဆိုလျှင် မည်သည့်နေရာတွင်မဆို မောင်းနင်းနိုင်သည်',
          ko: '자전거 전용 차선이라면 어디든 달릴 수 있다',
          fr: 'Vous pouvez rouler n\'importe où dans une piste cyclable',
          it: 'Si può andare ovunque in una corsia ciclabile',
          pt: 'Você pode andar em qualquer lugar na ciclofaixa'
        },
        correct: false
      },
      {
        text: {
          ja: '左側の自転車専用レーンを走らなければならない',
          en: 'You must use the bicycle lane on the left side',
          zh: '必须使用左侧的自行车专用道',
          vi: 'Bạn phải sử dụng làn xe đạp ở bên trái',
          tl: 'Dapat gumamit ng bicycle lane sa kaliwang bahagi',
          id: 'Harus menggunakan jalur sepeda di sisi kiri',
          my: 'ဘယ်ဘက်ရှိ စက်ဘီး သီးသန့်လမ်းကြောင်းကို မောင်းရမည်',
          ko: '왼쪽 자전거 전용 차선을 달려야 한다',
          fr: 'Vous devez utiliser la piste cyclable du côté gauche',
          it: 'È obbligatorio utilizzare la corsia ciclabile sul lato sinistro',
          pt: 'Você deve usar a ciclofaixa do lado esquerdo'
        },
        correct: true
      },
      {
        text: {
          ja: 'レーンがあれば右側でも問題ない',
          en: 'No problem on the right side as long as there is a lane',
          zh: '只要有车道，右侧也没问题',
          vi: 'Không sao ở bên phải miễn là có làn đường',
          tl: 'Walang problema sa kanang bahagi basta may lane',
          id: 'Tidak masalah di sisi kanan asalkan ada lajur',
          my: 'လမ်းကြောင်း ရှိသည် ဆိုလျှင် ညာဘက်တွင်လည်း ပြဿနာမရှိ',
          ko: '차선이 있으면 오른쪽도 문제없다',
          fr: 'Pas de problème sur le côté droit s\'il y a une voie',
          it: 'Nessun problema sul lato destro se c\'è una corsia',
          pt: 'Sem problema no lado direito se houver faixa'
        },
        correct: false
      },
      {
        text: {
          ja: '対向車がいなければ右側でもよい',
          en: 'Right side is fine if there are no oncoming vehicles',
          zh: '没有对向车辆的话，右侧也行',
          vi: 'Được đi bên phải nếu không có xe ngược chiều',
          tl: 'Okay ang kanang bahagi kung walang sasakyang paparating',
          id: 'Sisi kanan boleh jika tidak ada kendaraan yang datang',
          my: 'ဆန့်ကျင်ဘက်ကား မရှိလျှင် ညာဘက်ဖြစ်ပါသည်',
          ko: '대향차가 없으면 오른쪽도 괜찮다',
          fr: 'Le côté droit est acceptable s\'il n\'y a pas de véhicules en sens inverse',
          it: 'Il lato destro va bene se non ci sono veicoli in senso contrario',
          pt: 'O lado direito é aceitável se não houver veículos na direção contrária'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '自転車専用レーン（青線）が設置されている場合でも、左側通行の原則は守らなければなりません。右側の逆走レーンを使うことは右側通行違反になります。自転車は必ず進行方向左側のレーンを走行してください。',
      en: 'Even where a bicycle lane (blue line) exists, the left-side riding rule still applies. Using the right-side lane against the flow of traffic is a right-side riding violation. Always use the bicycle lane on your left.',
      zh: '即使设有自行车专用道（蓝线），也必须遵守靠左行驶原则。使用右侧逆行车道属于右侧通行违规。自行车必须始终使用行进方向左侧的车道。',
      vi: 'Ngay cả khi có làn xe đạp (đường xanh), quy tắc đi bên trái vẫn áp dụng. Sử dụng làn bên phải ngược chiều là vi phạm đi sai làn. Luôn dùng làn xe đạp ở bên trái hướng đi của bạn.',
      tl: 'Kahit mayroon nang bicycle lane (asul na linya), ang panuntunan ng pagmamaneho sa kaliwang bahagi ay nananatiling naaangkop. Ang paggamit ng lane sa kanang bahagi laban sa daloy ng trapiko ay paglabag. Palaging gamitin ang bicycle lane sa iyong kaliwa.',
      id: 'Meski ada jalur sepeda (garis biru), aturan berkendara di sisi kiri tetap berlaku. Menggunakan jalur sisi kanan melawan arus adalah pelanggaran. Selalu gunakan jalur sepeda di sisi kiri arah Anda.',
      my: 'စက်ဘီး သီးသန့်လမ်းကြောင်း (အပြာကြောင်း) ရှိသော်လည်း ဘယ်ဘက်မောင်း မူဝါဒ ကျုံးသည်။ ညာဘက် ဆန့်ကျင်ဘက်လမ်းကြောင်း သုံးခြင်းသည် ညာဘက်မောင်း ချိုးဖောက်မှု ဖြစ်သည်။ မောင်းနင်းရာ ဦးတည်ချက် ဘယ်ဘက်ရှိ လမ်းကြောင်းကို မောင်းပါ။',
      ko: '자전거 전용 차선（파란 선）이 설치되어 있는 경우에도 좌측 통행의 원칙은 지켜야 합니다. 오른쪽 역주행 차선을 이용하는 것은 우측 통행 위반이 됩니다. 자전거는 반드시 진행 방향 왼쪽의 차선을 주행하세요.',
      fr: 'Même là où il existe une piste cyclable (ligne bleue), la règle de circulation du côté gauche s\'applique toujours. Utiliser la voie de droite à contresens est une infraction. Utilisez toujours la piste cyclable sur votre gauche.',
      it: 'Anche dove esiste una corsia ciclabile (linea blu), si applica ancora la regola di circolazione sul lato sinistro. Utilizzare la corsia destra in senso opposto è una violazione. Usate sempre la corsia ciclabile sulla vostra sinistra.',
      pt: 'Mesmo onde existe uma ciclofaixa (linha azul), a regra de circular pelo lado esquerdo ainda se aplica. Usar a faixa direita na direção contrária é uma infração. Sempre use a ciclofaixa à sua esquerda.'
    },
    fineAmount: '5,000',
    criminal: false
  },

  /* ===== Q14: 横断歩道での歩行者妨害 ===== */
  {
    id: 14,
    question: {
      ja: '横断歩道を歩行者が渡っているのに止まらず、横断歩道の脇をすり抜けて通った。これは？',
      en: 'A pedestrian was crossing at a crosswalk, but you did not stop and squeezed past the side of it. What is this?',
      zh: '行人正在穿越人行横道，却没有停车，从人行横道旁边擦过去。这是？',
      vi: 'Người đi bộ đang qua đường ở vạch qua đường nhưng bạn không dừng và lách qua cạnh bên. Đây là gì?',
      tl: 'May pedestrian na tumatawid sa crosswalk, ngunit hindi ka huminto at dumaan sa tabi. Ano ito?',
      id: 'Ada pejalan kaki yang menyeberang di zebra cross, namun Anda tidak berhenti dan menerobos di sampingnya. Apa ini?',
      my: 'ကျောင်းသားလမ်းကို လူပြင် ဖြတ်ကျော်နေသော်လည်း မရပ်ဘဲ ဘေးကွပ် ဖြတ်ကျော်သွားသည်။ ဤသည်မှာ?',
      ko: '횡단보도를 보행자가 건너고 있는데 멈추지 않고 횡단보도 옆을 빠져 나갔습니다. 이것은?',
      fr: 'Un piéton traversait sur le passage clouté, mais vous ne vous êtes pas arrêté et avez passé en longeant son côté. Qu\'est-ce que c\'est ?',
      it: 'Un pedone stava attraversando sulle strisce, ma non ti sei fermato e sei passato di fianco. Cos\'è questo?',
      pt: 'Um pedestre estava atravessando na faixa de pedestres, mas você não parou e passou pelo lado. O que é isso?'
    },
    signImage: 'img/kiken14.png',
    category: '歩行者妨害',
    choices: [
      {
        text: {
          ja: '当たらなければ問題ない',
          en: 'No problem as long as you do not hit them',
          zh: '不碰到就没问题',
          vi: 'Không sao nếu không đụng vào họ',
          tl: 'Walang problema basta hindi tumama',
          id: 'Tidak masalah selama tidak menabrak',
          my: 'မတိုက်မိလျှင် ပြဿနာမရှိ',
          ko: '부딪히지 않으면 문제없다',
          fr: 'Pas de problème tant que vous ne les touchez pas',
          it: 'Nessun problema finché non si tocca il pedone',
          pt: 'Sem problema desde que não bata neles'
        },
        correct: false
      },
      {
        text: {
          ja: '横断歩行者等妨害の違反',
          en: 'Violation for obstructing a crossing pedestrian',
          zh: '妨碍过路行人等违规',
          vi: 'Vi phạm cản trở người đi bộ qua đường',
          tl: 'Paglabag sa pagharang sa pedestrian na tumatawid',
          id: 'Pelanggaran menghalangi pejalan kaki yang menyeberang',
          my: 'ကျောင်းသားလမ်းဖြတ်ကျော်သော လူပြင်ကို ဟန့်တားသည့် ချိုးဖောက်မှု',
          ko: '횡단 보행자 등 방해 위반',
          fr: 'Infraction pour obstruction d\'un piéton traversant',
          it: 'Violazione per ostruzione di un pedone che attraversa',
          pt: 'Infração por obstrução de pedestre atravessando'
        },
        correct: true
      },
      {
        text: {
          ja: '歩行者が先に気をつけるべき',
          en: 'It is the pedestrian who should be careful',
          zh: '应该是行人先注意',
          vi: 'Người đi bộ mới phải cẩn thận trước',
          tl: 'Ang pedestrian ang dapat mag-ingat',
          id: 'Pejalan kakilah yang harus berhati-hati',
          my: 'လမ်းလျှောက်သူ ကပါ ဦးစွာ သတိထားသင့်သည်',
          ko: '보행자가 먼저 주의해야 한다',
          fr: 'C\'est le piéton qui doit faire attention en premier',
          it: 'È il pedone che deve fare attenzione per primo',
          pt: 'É o pedestre que deve ter cuidado primeiro'
        },
        correct: false
      },
      {
        text: {
          ja: '自転車は横断歩道のルールに縛られない',
          en: 'Bicycles are not bound by crosswalk rules',
          zh: '自行车不受人行横道规则约束',
          vi: 'Xe đạp không bị ràng buộc bởi quy tắc vạch qua đường',
          tl: 'Hindi nakatali ang bisikleta sa mga patakaran ng crosswalk',
          id: 'Sepeda tidak terikat aturan zebra cross',
          my: 'စက်ဘီးသည် ကျောင်းသားလမ်း စည်းကမ်းဖြင့် ချုပ်နှောင်မခံ',
          ko: '자전거는 횡단보도 규칙에 구속되지 않는다',
          fr: 'Les vélos ne sont pas liés par les règles des passages piétons',
          it: 'Le biciclette non sono vincolate dalle norme sulle strisce pedonali',
          pt: 'As bicicletas não são obrigadas a seguir as regras das faixas de pedestres'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '横断歩道に歩行者がいる場合、自転車は必ず一時停止して歩行者を先に渡らせなければなりません（道路交通法第38条）。横断歩道の脇をすり抜けることも妨害行為に当たります。2026年5月施行の改正道路交通法で青切符の対象です。',
      en: 'When a pedestrian is at a crosswalk, bicycles must stop and let the pedestrian cross first (Road Traffic Law Article 38). Squeezing past the side of the crosswalk also counts as obstruction. Subject to a blue ticket under the revised law effective May 2026.',
      zh: '当行人在人行横道时，自行车必须临时停车让行人先过（《道路交通法》第38条）。从人行横道旁边擦过也属于妨碍行为。依据2026年5月实施的修订道路交通法，将被开具蓝色罚单。',
      vi: 'Khi có người đi bộ tại vạch qua đường, xe đạp phải dừng lại và nhường cho người đi bộ qua trước (Luật Giao thông Điều 38). Lách qua cạnh bên vạch qua đường cũng được tính là cản trở. Bị phạt phiếu xanh theo luật sửa đổi có hiệu lực tháng 5/2026.',
      tl: 'Kapag may pedestrian sa crosswalk, dapat huminto ang mga bisikleta at hayaan munang makatawid ang pedestrian (Road Traffic Law Article 38). Ang pagdaan sa tabi ng crosswalk ay itinuturing ding obstruction. Sakop ng blue ticket sa ilalim ng binagong batas na epektibo Mayo 2026.',
      id: 'Ketika ada pejalan kaki di zebra cross, sepeda harus berhenti dan membiarkan pejalan kaki menyeberang terlebih dahulu (UU Lalu Lintas Pasal 38). Menerobos di samping zebra cross pun termasuk penghalangan. Dikenai blue ticket berdasarkan revisi UU Mei 2026.',
      my: 'ကျောင်းသားလမ်းတွင် လူပြင် ရှိသောအခါ၊ စက်ဘီးသည် ရပ်ပြီး လူပြင်ကို ဦးစွာ ဖြတ်ကျော်ခွင့် ပြုရမည် (လမ်းအသွားအလာ ဥပဒေ ပုဒ်မ ၃၈)။ ကျောင်းသားလမ်း ဘေးကွပ် ဖြတ်ကျော်ခြင်းသည်လည်း ဟန့်တားမှု ဖြစ်သည်။',
      ko: '횡단보도에 보행자가 있을 경우, 자전거는 반드시 일시 정지하여 보행자를 먼저 건너게 해야 합니다（도로교통법 제38조）. 횡단보도 옆을 빠져 나가는 것도 방해 행위에 해당합니다. 2026년 5월 시행된 개정 도로교통법으로 파란 딱지의 대상입니다.',
      fr: 'Lorsqu\'un piéton est sur un passage clouté, les vélos doivent s\'arrêter et laisser le piéton traverser en premier (Code de la route, article 38). Longer le bord du passage clouté compte également comme obstruction. Cela est passible d\'un ticket bleu en vertu de la loi révisée en vigueur en mai 2026.',
      it: 'Quando un pedone è sulle strisce, le biciclette devono fermarsi e lasciare che il pedone attraversi per primo (Codice della Strada, articolo 38). Passare di fianco alle strisce conta anch\'esso come ostruzione. È soggetto a ticket blu ai sensi della revisione del Codice della Strada in vigore da maggio 2026.',
      pt: 'Quando há um pedestre na faixa de pedestres, as bicicletas devem parar e deixar o pedestre atravessar primeiro (Lei de Trânsito, Artigo 38). Passar pelo lado da faixa também conta como obstrução. Está sujeito a ticket azul conforme a revisão da Lei de Trânsito em vigor a partir de maio de 2026.'
    },
    fineAmount: '6,000',
    criminal: false
  },

  /* ===== Q15: 歩行者専用道路での妨害 ===== */
  {
    id: 15,
    question: {
      ja: '歩行者専用道路を自転車で速く走り、歩行者の間を縫うように走り抜けた。どうなりますか？',
      en: 'You rode your bicycle fast on a pedestrian-only road and weaved between pedestrians. What happens?',
      zh: '在步行者专用道路上骑自行车快速行驶，穿梭在行人之间。会有什么问题？',
      vi: 'Bạn đi xe đạp nhanh trên đường chỉ dành cho người đi bộ và len lỏi giữa người đi bộ. Điều gì sẽ xảy ra?',
      tl: 'Nagmaneho ka nang mabilis ng bisikleta sa isang pedestrian-only road at dumaan sa pagitan ng mga pedestrian. Ano ang mangyayari?',
      id: 'Anda bersepeda cepat di jalan khusus pejalan kaki dan menerobos di antara pejalan kaki. Apa yang akan terjadi?',
      my: 'လမ်းလျှောက်သူ သီးသန့်လမ်းတွင် စက်ဘီးကို မြန်မြန် မောင်းကာ လမ်းလျှောက်သူများ ကြားတွင် ဆန်ထိုးသွားသည်။ မည်သို့ ဖြစ်မည်နည်း?',
      ko: '보행자 전용 도로를 자전거로 빠르게 달려 보행자 사이를 누비며 달렸습니다. 어떻게 됩니까?',
      fr: 'Vous avez roulé rapidement à vélo sur une route réservée aux piétons et avez slalomé entre les piétons. Que se passe-t-il ?',
      it: 'Hai pedalato velocemente su una strada riservata ai pedoni, zigzagando tra i pedoni. Cosa succede?',
      pt: 'Você pedalou rapidamente em uma rua exclusiva para pedestres, ziguezagueando entre eles. O que acontece?'
    },
    signImage: 'img/kiken15.png',
    category: '歩行者妨害',
    choices: [
      {
        text: {
          ja: '歩行者専用道路は自転車も自由に走れる',
          en: 'Bicycles can ride freely on pedestrian-only roads',
          zh: '步行者专用道路自行车也可以自由骑行',
          vi: 'Xe đạp có thể đi tự do trên đường chỉ dành cho người đi bộ',
          tl: 'Maaaring libre sumakay ang bisikleta sa pedestrian-only road',
          id: 'Sepeda bisa melaju bebas di jalan khusus pejalan kaki',
          my: 'လမ်းလျှောက်သူ သီးသန့်လမ်းတွင် စက်ဘီးသည် လွတ်လပ်စွာ မောင်းနင်းနိုင်သည်',
          ko: '보행자 전용 도로는 자전거도 자유롭게 달릴 수 있다',
          fr: 'Les vélos peuvent rouler librement sur les routes réservées aux piétons',
          it: 'Le biciclette possono andare liberamente sulle strade riservate ai pedoni',
          pt: 'As bicicletas podem circular livremente em ruas exclusivas para pedestres'
        },
        correct: false
      },
      {
        text: {
          ja: '歩行者優先義務違反・歩行者妨害',
          en: 'Pedestrian-priority violation and pedestrian obstruction',
          zh: '违反行人优先义务及妨碍行人',
          vi: 'Vi phạm nghĩa vụ ưu tiên người đi bộ và cản trở người đi bộ',
          tl: 'Paglabag sa pedestrian-priority obligation at pedestrian obstruction',
          id: 'Pelanggaran kewajiban prioritas pejalan kaki dan penghalangan pejalan kaki',
          my: 'လမ်းလျှောက်သူ ဦးစားပေး တာဝန်ဝတ္တရား ချိုးဖောက်မှုနှင့် လမ်းလျှောက်သူ ဟန့်တားမှု',
          ko: '보행자 우선 의무 위반·보행자 방해',
          fr: 'Violation de l\'obligation de priorité aux piétons et obstruction des piétons',
          it: 'Violazione dell\'obbligo di priorità ai pedoni e ostruzione dei pedoni',
          pt: 'Violação da obrigação de prioridade aos pedestres e obstrução de pedestres'
        },
        correct: true
      },
      {
        text: {
          ja: 'ベルを鳴らせば問題ない',
          en: 'No problem if you ring your bell',
          zh: '按铃就没问题',
          vi: 'Không sao nếu bạn rung chuông',
          tl: 'Walang problema kung mag-ring ng bell',
          id: 'Tidak masalah jika membunyikan bel',
          my: 'ခေါင်းလောင်း မြည်စေလျှင် ပြဿနာမရှိ',
          ko: '벨을 울리면 문제없다',
          fr: 'Pas de problème si vous sonnez la cloche',
          it: 'Nessun problema se si suona il campanello',
          pt: 'Sem problema se tocar a campainha'
        },
        correct: false
      },
      {
        text: {
          ja: '車道が危険なら歩道をどう走ってもよい',
          en: 'You can ride any way on the footpath if the road is dangerous',
          zh: '如果车道危险，可以任意在人行道上骑行',
          vi: 'Có thể đi bất kỳ cách nào trên vỉa hè nếu đường nguy hiểm',
          tl: 'Maaaring sumakay kahit paano sa sidewalk kung mapanganib ang kalsada',
          id: 'Boleh berkendara sesuka hati di trotoar jika jalan berbahaya',
          my: 'လမ်းမ အန္တရာယ်ရှိလျှင် လမ်းလျှောက်ကွင်းတွင် မည်သို့မဆို မောင်းနင်းနိုင်သည်',
          ko: '차도가 위험하면 인도를 어떻게 달려도 좋다',
          fr: 'Vous pouvez rouler comme vous voulez sur le trottoir si la route est dangereuse',
          it: 'Si può andare in qualsiasi modo sul marciapiede se la strada è pericolosa',
          pt: 'Você pode pedalar de qualquer forma na calçada se a rua for perigosa'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '歩行者専用道路は歩行者のための道路です。補助標識で自転車の通行が認められている場合でも、歩行者優先で徐行し歩行者を妨害してはなりません。速く走ったりすり抜けたりすれば歩行者妨害・安全運転義務違反です。',
      en: 'A pedestrian-only road is for pedestrians. Even when a supplementary sign permits bicycle access, you must give priority to pedestrians and ride slowly. Riding fast or weaving between people is pedestrian obstruction and a safe-riding violation.',
      zh: '步行者专用道路是为行人设置的道路。即使有辅助标志允许自行车通行，也必须以行人优先、低速行驶，不得妨碍行人。快速行驶或穿梭其间均属妨碍行人及违反安全驾驶义务。',
      vi: 'Đường chỉ dành cho người đi bộ là dành cho người đi bộ. Ngay cả khi biển phụ cho phép xe đạp vào, bạn phải ưu tiên cho người đi bộ và đi chậm. Đi nhanh hoặc len lỏi giữa người đi bộ là cản trở người đi bộ và vi phạm nghĩa vụ lái xe an toàn.',
      tl: 'Ang pedestrian-only road ay para sa mga pedestrian. Kahit na pinahihintulutan ng supplementary sign ang access ng bisikleta, dapat mong unahin ang mga pedestrian at magmaneho nang dahan-dahan. Ang pagmamaneho nang mabilis o pag-weave sa pagitan ng mga tao ay pedestrian obstruction at paglabag sa safe-riding.',
      id: 'Jalan khusus pejalan kaki diperuntukkan bagi pejalan kaki. Meski ada tanda tambahan yang mengizinkan akses sepeda, Anda harus mendahulukan pejalan kaki dan berkendara perlahan. Berkendara cepat atau menerobos di antara orang adalah penghalangan pejalan kaki dan pelanggaran keselamatan.',
      my: 'လမ်းလျှောက်သူ သီးသန့်လမ်းသည် လမ်းလျှောက်သူများ အတွက်ဖြစ်သည်။ ထပ်ဖြည့်ဆိုင်းဘုတ် ခွင့်ပြုသော်လည်း လမ်းလျှောက်သူများကို ဦးစားပေးကာ နှေးနှေး မောင်းရမည်။ မြန်မြန် မောင်းခြင်း သို့မဟုတ် ဆန်ထိုးခြင်းသည် ဟန့်တားမှု ဖြစ်သည်။',
      ko: '보행자 전용 도로는 보행자를 위한 도로입니다. 보조 표지로 자전거 통행이 인정되는 경우에도 보행자 우선으로 서행하고 보행자를 방해해서는 안 됩니다. 빠르게 달리거나 빠져 나가면 보행자 방해·안전 운전 의무 위반입니다.',
      fr: 'Une route réservée aux piétons est destinée aux piétons. Même lorsqu\'un panneau complémentaire autorise l\'accès aux vélos, vous devez donner la priorité aux piétons et rouler lentement. Rouler vite ou slalomer entre les personnes constitue une obstruction des piétons et une violation de l\'obligation de conduite sécurisée.',
      it: 'Una strada riservata ai pedoni è per i pedoni. Anche quando un segnale supplementare permette l\'accesso alle biciclette, è obbligatorio dare la priorità ai pedoni e pedalare lentamente. Andare veloce o zigzagare tra le persone costituisce un\'ostruzione dei pedoni e una violazione dell\'obbligo di guida sicura.',
      pt: 'Uma rua exclusiva para pedestres é para pedestres. Mesmo quando uma placa suplementar permite acesso para bicicletas, você deve dar prioridade aos pedestres e pedalar devagar. Andar rápido ou ziguezaguear entre as pessoas constitui obstrução de pedestres e violação da obrigação de condução segura.'
    },
    fineAmount: '6,000',
    criminal: false
  },

  /* ===== Q16: ベルによる歩行者妨害 ===== */
  {
    id: 16,
    question: {
      ja: '歩道で歩行者が前を歩いていたので、ベルを鳴らして道を空けさせた。問題は？',
      en: 'A pedestrian was walking ahead of you on the footpath, so you rang your bell to make them move aside. Is there a problem?',
      zh: '人行道上行人走在前面，于是按铃让对方让路。有问题吗？',
      vi: 'Có người đi bộ đi trước bạn trên vỉa hè, nên bạn rung chuông để họ nhường đường. Có vấn đề không?',
      tl: 'May pedestrian na naglalakad sa harap mo sa footpath, kaya nag-ring ka ng bell para tumabi sila. Mayroon bang problema?',
      id: 'Ada pejalan kaki berjalan di depan Anda di trotoar, jadi Anda membunyikan bel agar mereka minggir. Ada masalah?',
      my: 'လမ်းလျှောက်ကွင်းတွင် လူပြင် ရှေ့တွင် လျှောက်နေသောကြောင့် ခေါင်းလောင်း မြည်ကာ လမ်းဖွင့်ခိုင်းသည်။ ပြဿနာရှိသလား?',
      ko: '인도에서 보행자가 앞을 걷고 있었기 때문에 벨을 울려 길을 비켜 달라고 했습니다. 문제는?',
      fr: 'Un piéton marchait devant vous sur le trottoir, alors vous avez sonné la cloche pour lui demander de s\'écarter. Y a-t-il un problème ?',
      it: 'Un pedone stava camminando davanti a te sul marciapiede, quindi hai suonato il campanello per farlo spostare. C\'è un problema?',
      pt: 'Um pedestre estava caminhando à sua frente na calçada, então você tocou a campainha para fazê-lo se afastar. Há um problema?'
    },
    signImage: 'img/kiken16.png',
    category: '歩行者妨害',
    choices: [
      {
        text: {
          ja: '警告するためのベルは常に使ってよい',
          en: 'You can always use the bell as a warning',
          zh: '警告用的铃可以随时按',
          vi: 'Bạn luôn có thể dùng chuông để cảnh báo',
          tl: 'Palaging maaaring gamitin ang bell bilang babala',
          id: 'Bel boleh selalu digunakan sebagai peringatan',
          my: 'သတိပေးရန် ခေါင်းလောင်းကို အမြဲ သုံးနိုင်သည်',
          ko: '경고를 위한 벨은 항상 사용해도 좋다',
          fr: 'Vous pouvez toujours utiliser la cloche pour avertir',
          it: 'Si può sempre usare il campanello per avvertire',
          pt: 'Você sempre pode usar a campainha para avisar'
        },
        correct: false
      },
      {
        text: {
          ja: 'ベルで歩行者をどかすのは歩行者妨害・警音器使用義務違反',
          en: 'Using the bell to move a pedestrian is pedestrian obstruction and an improper use of a warning device',
          zh: '鸣铃驱赶行人属于妨碍行人及违反警示器使用义务',
          vi: 'Dùng chuông để đẩy người đi bộ là cản trở người đi bộ và sử dụng thiết bị cảnh báo sai',
          tl: 'Ang paggamit ng bell para ilayo ang pedestrian ay pedestrian obstruction at maling paggamit ng warning device',
          id: 'Membunyikan bel untuk mengusir pejalan kaki adalah penghalangan dan pelanggaran penggunaan alat peringatan',
          my: 'ခေါင်းလောင်း မြည်ကာ လမ်းလျှောက်သူကို ဖယ်ရှားခိုင်းခြင်းသည် ဟန့်တားမှုနှင့် သတိပေးကိရိယာ မမှန်ကန်သောသုံးစွဲမှု',
          ko: '벨로 보행자를 비키게 하는 것은 보행자 방해·경음기 사용 의무 위반',
          fr: 'Sonner la cloche pour déplacer un piéton est une obstruction et une mauvaise utilisation du dispositif d\'avertissement',
          it: 'Usare il campanello per spostare un pedone è un\'ostruzione e un uso improprio del dispositivo di segnalazione',
          pt: 'Usar a campainha para mover um pedestre é obstrução e uso indevido de dispositivo de aviso'
        },
        correct: true
      },
      {
        text: {
          ja: '歩道では自転車が優先',
          en: 'Bicycles have priority on the footpath',
          zh: '人行道上自行车优先',
          vi: 'Xe đạp được ưu tiên trên vỉa hè',
          tl: 'Ang bisikleta ang may priority sa footpath',
          id: 'Sepeda punya prioritas di trotoar',
          my: 'လမ်းလျှောက်ကွင်းတွင် စက်ဘီးကို ဦးစားပေးသည်',
          ko: '인도에서는 자전거가 우선',
          fr: 'Les vélos ont la priorité sur le trottoir',
          it: 'Le biciclette hanno la priorità sul marciapiede',
          pt: 'As bicicletas têm prioridade na calçada'
        },
        correct: false
      },
      {
        text: {
          ja: '歩行者が気づかないのが悪い',
          en: 'It is the pedestrian\'s fault for not noticing',
          zh: '是行人没注意的问题',
          vi: 'Lỗi tại người đi bộ không để ý',
          tl: 'Kasalanan ng pedestrian ang hindi mapansin',
          id: 'Salah pejalan kaki karena tidak menyadari',
          my: 'လမ်းလျှောက်သူ မသတိထားသောကြောင့် သူ့အပြစ်ဖြစ်သည်',
          ko: '보행자가 알아채지 못하는 것이 나쁘다',
          fr: 'C\'est la faute du piéton de ne pas remarquer',
          it: 'È colpa del pedone non essersi accorto',
          pt: 'É culpa do pedestre não ter percebido'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '自転車のベル（警音器）は危険回避など法定の場合にのみ使用できます。歩行者をどかすためにベルを鳴らすのは、警音器使用義務違反かつ歩行者妨害にあたります。歩道では歩行者最優先。自転車は降りて押すか、歩行者が通るのを待ちましょう。',
      en: 'A bicycle bell (warning device) may only be used in legally prescribed situations such as avoiding danger. Ringing it to move pedestrians out of the way is both an improper use of a warning device and pedestrian obstruction. Pedestrians have priority on the footpath. Dismount and push your bicycle, or wait for pedestrians to pass.',
      zh: '自行车铃（警告器）只能在法律规定的情况下使用，例如避免危险。为驱赶行人而鸣铃，属于违反警示器使用义务及妨碍行人。人行道上行人最优先，请下车推行或等待行人通过。',
      vi: 'Chuông xe đạp (thiết bị cảnh báo) chỉ được sử dụng trong các tình huống theo quy định của pháp luật như tránh nguy hiểm. Rung chuông để đẩy người đi bộ ra là vừa sử dụng thiết bị cảnh báo sai mục đích vừa cản trở người đi bộ. Trên vỉa hè, người đi bộ được ưu tiên. Hãy xuống xe dắt bộ hoặc chờ người đi bộ qua.',
      tl: 'Ang bell ng bisikleta (warning device) ay maaari lamang gamitin sa mga sitwasyong itinakda ng batas tulad ng pag-iwas sa panganib. Ang pag-ring nito para ilayo ang mga pedestrian ay parehong maling paggamit ng warning device at pedestrian obstruction. Ang mga pedestrian ay may priority sa footpath. Bumaba at itulak ang iyong bisikleta, o maghintay ng mga pedestrian.',
      id: 'Bel sepeda (alat peringatan) hanya boleh digunakan dalam situasi yang ditentukan hukum seperti menghindari bahaya. Membunyikannya untuk mengusir pejalan kaki adalah pelanggaran penggunaan alat peringatan sekaligus penghalangan pejalan kaki. Pejalan kaki punya prioritas di trotoar. Turun dan dorong sepeda, atau tunggu pejalan kaki lewat.',
      my: 'စက်ဘီး ခေါင်းလောင်း (သတိပေးကိရိယာ) ကို ဥပဒေ သတ်မှတ်ထားသည့် အန္တရာယ်ကင်းရှင်းရေး ကဲ့သို့သော အခြေအနေများတွင်သာ သုံးနိုင်သည်။ လမ်းလျှောက်သူကို ဖယ်ရှားရန် မြည်ကာ ခေါင်းလောင်း တီးခြင်းသည် သတိပေးကိရိယာ မမှန်ကန်သောသုံးစွဲမှုနှင့် ဟန့်တားမှု ဖြစ်သည်။ လမ်းလျှောက်ကွင်းတွင် လမ်းလျှောက်သူကို ဦးစားပေးသည်။',
      ko: '자전거 벨（경음기）은 위험 회피 등 법정 경우에만 사용할 수 있습니다. 보행자를 비키게 하기 위해 벨을 울리는 것은 경음기 사용 의무 위반이자 보행자 방해에 해당합니다. 인도에서는 보행자 최우선. 자전거는 내려서 밀거나 보행자가 지나갈 때까지 기다립시다.',
      fr: 'Une sonnette de vélo (dispositif d\'avertissement) ne peut être utilisée que dans les situations légalement prescrites, comme éviter un danger. Sonner pour faire s\'écarter des piétons est à la fois une mauvaise utilisation d\'un dispositif d\'avertissement et une obstruction aux piétons. Les piétons ont la priorité sur le trottoir. Descendez et poussez votre vélo, ou attendez que les piétons passent.',
      it: 'Un campanello da bicicletta (dispositivo di segnalazione) può essere utilizzato solo in situazioni prescritte dalla legge, come evitare un pericolo. Suonarlo per fare spostare i pedoni è sia un uso improprio che un\'ostruzione ai pedoni. I pedoni hanno la priorità sul marciapiede. Scendete e spingete la bicicletta, o aspettate che i pedoni passino.',
      pt: 'Uma campainha de bicicleta (dispositivo de aviso) só pode ser usada em situações legalmente prescritas, como evitar perigos. Tocá-la para fazer os pedestres se afastarem é tanto um uso indevido quanto obstrução de pedestres. Os pedestres têm prioridade na calçada. Desça e empurre a bicicleta, ou espere os pedestres passarem.'
    },
    fineAmount: '3,000',
    criminal: false
  },

  /* ===== Q17: 無灯火運転 ===== */
  {
    id: 17,
    question: {
      ja: '夜間、歩道を無灯火で走行中に歩行者と接触しそうになった。どんな違反ですか？',
      en: 'At night, you rode without lights on the footpath and nearly collided with a pedestrian. What violation is this?',
      zh: '夜间在人行道无灯骑行时，险些与行人相撞。这是哪种违规？',
      vi: 'Ban đêm, bạn đi xe đạp không có đèn trên vỉa hè và suýt va vào người đi bộ. Đây là vi phạm gì?',
      tl: 'Sa gabi, nagmaneho ka nang walang ilaw sa footpath at halos nabangga ang isang pedestrian. Anong paglabag ito?',
      id: 'Malam hari, Anda bersepeda tanpa lampu di trotoar dan hampir menabrak pejalan kaki. Pelanggaran apa ini?',
      my: 'ညဘက်တွင် မီးမပါဘဲ လမ်းလျှောက်ကွင်းတွင် မောင်းနင်းစဉ် လမ်းလျှောက်သူနှင့် မတော်တဆ တိုက်မှုနီးပါးဖြစ်ခဲ့သည်။ မည်သည့် ချိုးဖောက်မှုနည်း?',
      ko: '야간에 인도를 무등화로 주행 중에 보행자와 접촉할 뻔했습니다. 어떤 위반입니까?',
      fr: 'La nuit, vous rouliez sans lumières sur le trottoir et avez failli entrer en collision avec un piéton. De quelle infraction s\'agit-il ?',
      it: 'Di notte, stavi pedalando senza luci sul marciapiede e hai quasi urtato un pedone. Di quale violazione si tratta?',
      pt: 'À noite, você pedalava sem luzes na calçada e quase colidiu com um pedestre. Que infração é essa?'
    },
    signImage: 'img/kiken17.png',
    category: '歩行者妨害',
    choices: [
      {
        text: {
          ja: '夜間の無灯火は自転車には関係ない',
          en: 'Riding without lights at night does not apply to bicycles',
          zh: '夜间无灯与自行车无关',
          vi: 'Đi xe không có đèn vào ban đêm không áp dụng cho xe đạp',
          tl: 'Ang pagmamaneho nang walang ilaw sa gabi ay hindi naaangkop sa bisikleta',
          id: 'Berkendara tanpa lampu malam hari tidak berlaku untuk sepeda',
          my: 'ညဘက် မီးမပါဘဲ မောင်းခြင်းသည် စက်ဘီးနှင့် မဆိုင်',
          ko: '야간 무등화는 자전거에는 관계없다',
          fr: 'Circuler sans lumières la nuit ne s\'applique pas aux vélos',
          it: 'Andare senza luci di notte non si applica alle biciclette',
          pt: 'Circular sem luzes à noite não se aplica a bicicletas'
        },
        correct: false
      },
      {
        text: {
          ja: '無灯火運転＋安全運転義務違反',
          en: 'Riding without lights + safe-driving obligation violation',
          zh: '无灯骑行＋违反安全驾驶义务',
          vi: 'Đi xe không có đèn + vi phạm nghĩa vụ lái xe an toàn',
          tl: 'Pagmamaneho nang walang ilaw + paglabag sa safe-driving obligation',
          id: 'Berkendara tanpa lampu + pelanggaran kewajiban berkendara aman',
          my: 'မီးမပါဘဲ မောင်းနင်းမှု + လုံခြုံသောမောင်းနှင်မှု တာဝန်ဝတ္တရားချိုးဖောက်မှု',
          ko: '무등화 운전＋안전 운전 의무 위반',
          fr: 'Circulation sans lumières + violation de l\'obligation de conduite sécurisée',
          it: 'Guida senza luci + violazione dell\'obbligo di guida sicura',
          pt: 'Circular sem luzes + violação da obrigação de condução segura'
        },
        correct: true
      },
      {
        text: {
          ja: '反射材をつけていれば無灯火でよい',
          en: 'Reflectors are sufficient — no need for a light',
          zh: '有反光材料就不需要灯',
          vi: 'Có vật liệu phản quang là đủ — không cần đèn',
          tl: 'Sapat na ang mga reflector — hindi na kailangan ng ilaw',
          id: 'Reflektor sudah cukup — tidak perlu lampu',
          my: 'ဖြန့်ကျဲစေသောပစ္စည်း တပ်ဆင်ထားလျှင် မီးမလိုအပ်',
          ko: '반사재를 달고 있으면 무등화도 괜찮다',
          fr: 'Les réflecteurs sont suffisants — pas besoin de lumière',
          it: 'I catarifrangenti sono sufficienti — non c\'è bisogno di luci',
          pt: 'Refletores são suficientes — não é necessária luz'
        },
        correct: false
      },
      {
        text: {
          ja: '街灯があれば灯火不要',
          en: 'No light needed if there are streetlights',
          zh: '有路灯就不需要自行车灯',
          vi: 'Không cần đèn nếu có đèn đường',
          tl: 'Hindi kailangan ng ilaw kung mayroon nang streetlight',
          id: 'Tidak perlu lampu jika ada lampu jalan',
          my: 'လမ်းမီးများ ရှိလျှင် မီးမလိုအပ်',
          ko: '가로등이 있으면 등화 불필요',
          fr: 'Pas besoin de lumière s\'il y a des réverbères',
          it: 'Non c\'è bisogno di luci se ci sono lampioni',
          pt: 'Não é necessária luz se houver postes de iluminação'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '夜間（日没〜日出）は自転車もライトを点灯する義務があります（道路交通法第52条）。無灯火での走行は「灯火不備（無灯火）」の違反です。視認性が下がり歩行者や他の車両と衝突する危険性が高まります。',
      en: 'Between sunset and sunrise, bicycles are required to have their lights on (Road Traffic Law Article 52). Riding without a light is a "lighting deficiency" violation. Visibility drops significantly, greatly increasing the risk of collision with pedestrians and other vehicles.',
      zh: '夜间（日落至日出）自行车也必须开灯（《道路交通法》第52条）。无灯行驶属于"灯光不足（无灯）"违规。能见度降低，与行人或其他车辆碰撞的风险大幅上升。',
      vi: 'Từ lúc mặt trời lặn đến khi mọc, xe đạp cũng phải bật đèn (Luật Giao thông Điều 52). Đi xe không có đèn là vi phạm "thiếu chiếu sáng." Tầm nhìn giảm đáng kể, làm tăng nguy cơ va chạm với người đi bộ và các phương tiện khác.',
      tl: 'Sa pagitan ng paglubog at pagsikat ng araw, ang mga bisikleta ay kailangan ding magpalit ng ilaw (Road Traffic Law Article 52). Ang pagmamaneho nang walang ilaw ay paglabag sa "kakulangan sa ilaw." Nababawasan ang visibility, na lubos na nagpapataas ng panganib ng banggaan.',
      id: 'Antara matahari terbenam dan terbit, sepeda juga wajib menyalakan lampu (UU Lalu Lintas Pasal 52). Berkendara tanpa lampu adalah pelanggaran "kekurangan penerangan." Visibilitas menurun drastis, meningkatkan risiko tabrakan dengan pejalan kaki dan kendaraan lain.',
      my: 'နေဝင်ချိန်မှ နေထွက်ချိန်အထိ၊ စက်ဘီးသည်လည်း မီးဖွင့်ရန် တာဝန်ရှိသည် (လမ်းအသွားအလာ ဥပဒေ ပုဒ်မ ၅၂)။ မီးမပါဘဲ မောင်းနင်းခြင်းသည် "မီးအလင်းအားနည်း" ချိုးဖောက်မှု ဖြစ်သည်။ မြင်ကွင်း လျော့ကျပြီး လမ်းလျှောက်သူများနှင့် ကားများနှင့် တိုက်မှု အန္တရာယ် မြင့်မားသည်။',
      ko: '야간（일몰~일출）에는 자전거도 라이트를 켤 의무가 있습니다（도로교통법 제52조）. 무등화로 달리는 것은 "등화 불비（무등화）" 위반입니다. 시인성이 낮아져 보행자나 다른 차량과 충돌할 위험성이 높아집니다.',
      fr: 'Entre le coucher et le lever du soleil, les vélos sont tenus d\'avoir leurs lumières allumées (Code de la route, article 52). Rouler sans lumière est une infraction d\'« éclairage déficient ». La visibilité chute considérablement, augmentant grandement le risque de collision avec des piétons et d\'autres véhicules.',
      it: 'Tra il tramonto e l\'alba, anche le biciclette sono obbligate ad avere le luci accese (Codice della Strada, articolo 52). Andare senza luci è una violazione di "illuminazione insufficiente". La visibilità cala significativamente, aumentando notevolmente il rischio di collisione con pedoni e altri veicoli.',
      pt: 'Entre o pôr do sol e o amanhecer, as bicicletas são obrigadas a ter as luzes acesas (Lei de Trânsito, Artigo 52). Circular sem luzes é uma infração de "deficiência de iluminação". A visibilidade cai significativamente, aumentando muito o risco de colisão com pedestres e outros veículos.'
    },
    fineAmount: '5,000',
    criminal: false
  },

  /* ===== Q18: 複合違反（4つ同時） ===== */
  {
    id: 18,
    question: {
      ja: '夜間、イヤホンをしてスマホを手に持ったまま赤信号を無視してライトなしで自転車で走った。このとき同時にいくつの違反をしていますか？',
      en: 'At night, you cycled while wearing earphones, holding a smartphone, running a red light, and riding without a light. How many violations did you commit at once?',
      zh: '夜间，戴着耳机手持手机、无视红灯、无灯骑自行车。此时同时犯了几个违规？',
      vi: 'Ban đêm, bạn đạp xe đeo tai nghe, cầm điện thoại, vượt đèn đỏ và không có đèn. Bạn đã vi phạm bao nhiêu lỗi cùng một lúc?',
      tl: 'Sa gabi, nagmaneho ka ng bisikleta na may suot na earphone, hawak ang smartphone, nilabag ang pulang ilaw, at walang ilaw. Ilang paglabag ang nagawa mo nang sabay?',
      id: 'Malam hari, Anda bersepeda sambil memakai earphone, memegang smartphone, menerobos lampu merah, dan tanpa lampu. Berapa pelanggaran yang Anda lakukan sekaligus?',
      my: 'ညဘက်တွင် နားကြပ်တပ်ဆင်ကာ smartphone ကိုင်ကာ အနီရောင်မီးကို ဖြတ်ကာ မီးမပါဘဲ စက်ဘီး မောင်းသည်။ တစ်ပြိုင်နက် ချိုးဖောက်မှု မည်မျှ ရှိနည်း?',
      ko: '야간에 이어폰을 끼고 스마트폰을 손에 들고 빨간 신호를 무시하고 라이트 없이 자전거로 달렸습니다. 이때 동시에 몇 가지 위반을 했습니까?',
      fr: 'La nuit, vous avez fait du vélo avec des écouteurs, tenant un smartphone, grillant un feu rouge, et sans lumières. Combien d\'infractions avez-vous commises simultanément ?',
      it: 'Di notte, hai pedalato con gli auricolari, tenendo uno smartphone, passando con il rosso e senza luci. Quante violazioni hai commesso contemporaneamente?',
      pt: 'À noite, você pedalou usando fones de ouvido, segurando um smartphone, passando no sinal vermelho e sem luzes. Quantas infrações você cometeu ao mesmo tempo?'
    },
    signImage: 'img/kiken18.png',
    category: 'ながら運転',
    choices: [
      {
        text: {
          ja: '1つ（スマホを持っているだけ）',
          en: '1 (just holding the smartphone)',
          zh: '1个（只是手持手机）',
          vi: '1 (chỉ cầm điện thoại)',
          tl: '1 (hawak lang ang smartphone)',
          id: '1 (hanya memegang smartphone)',
          my: '၁ ခု (smartphone ကိုင်ရုံသာ)',
          ko: '1가지（스마트폰을 들고 있을 뿐）',
          fr: '1 (seulement tenir le smartphone)',
          it: '1 (solo tenere lo smartphone)',
          pt: '1 (apenas segurar o smartphone)'
        },
        correct: false
      },
      {
        text: {
          ja: '2つ（スマホ＋信号無視）',
          en: '2 (smartphone + red light)',
          zh: '2个（手机＋闯红灯）',
          vi: '2 (điện thoại + vượt đèn đỏ)',
          tl: '2 (smartphone + pulang ilaw)',
          id: '2 (smartphone + lampu merah)',
          my: '၂ ခု (smartphone + မီးပြိုင့်)',
          ko: '2가지（스마트폰＋신호 무시）',
          fr: '2 (smartphone + feu rouge)',
          it: '2 (smartphone + rosso)',
          pt: '2 (smartphone + sinal vermelho)'
        },
        correct: false
      },
      {
        text: {
          ja: '3つ（スマホ＋イヤホン＋信号無視）',
          en: '3 (smartphone + earphones + red light)',
          zh: '3个（手机＋耳机＋闯红灯）',
          vi: '3 (điện thoại + tai nghe + vượt đèn đỏ)',
          tl: '3 (smartphone + earphone + pulang ilaw)',
          id: '3 (smartphone + earphone + lampu merah)',
          my: '၃ ခု (smartphone + နားကြပ် + မီးပြိုင့်)',
          ko: '3가지（스마트폰＋이어폰＋신호 무시）',
          fr: '3 (smartphone + écouteurs + feu rouge)',
          it: '3 (smartphone + auricolari + rosso)',
          pt: '3 (smartphone + fones + sinal vermelho)'
        },
        correct: false
      },
      {
        text: {
          ja: '4つ（スマホ＋イヤホン＋信号無視＋無灯火）',
          en: '4 (smartphone + earphones + red light + no light)',
          zh: '4个（手机＋耳机＋闯红灯＋无灯）',
          vi: '4 (điện thoại + tai nghe + vượt đèn đỏ + không đèn)',
          tl: '4 (smartphone + earphone + pulang ilaw + walang ilaw)',
          id: '4 (smartphone + earphone + lampu merah + tanpa lampu)',
          my: '၄ ခု (smartphone + နားကြပ် + မီးပြိုင့် + မီးမပါ)',
          ko: '4가지（스마트폰＋이어폰＋신호 무시＋무등화）',
          fr: '4 (smartphone + écouteurs + feu rouge + sans lumières)',
          it: '4 (smartphone + auricolari + rosso + senza luci)',
          pt: '4 (smartphone + fones + sinal vermelho + sem luzes)'
        },
        correct: true
      }
    ],
    explanation: {
      ja: 'この行為は4つの違反が同時に重なっています。①スマホ保持（ながら運転）、②イヤホンで周囲の音が聞こえない（安全運転義務違反）、③赤信号を無視（信号無視）、④夜間ライトなし（無灯火）。違反が重なるほど罰則も重くなります。',
      en: 'Four violations are stacked at once: ① holding a smartphone (distracted riding), ② earphones blocking surrounding sounds (safe-riding obligation violation), ③ running a red light (signal violation), ④ no light at night (riding without lighting). The more violations you stack, the heavier the penalties.',
      zh: '这一行为同时叠加了4项违规：①手持手机（边骑边看）、②耳机导致听不到周围声音（违反安全驾驶义务）、③无视红灯（信号违规）、④夜间无灯（无灯行驶）。违规叠加越多，处罚越重。',
      vi: 'Hành động này chồng chất 4 vi phạm cùng lúc: ① cầm điện thoại (lái xe mất tập trung), ② tai nghe chặn âm thanh xung quanh (vi phạm nghĩa vụ lái xe an toàn), ③ vượt đèn đỏ (vi phạm tín hiệu), ④ không có đèn ban đêm (đi xe không có đèn). Càng nhiều vi phạm, hình phạt càng nặng.',
      tl: 'Apat na paglabag ang nagsasabay: ① paghawak ng smartphone (distracted riding), ② earphone na naghaharangan ng tunog sa paligid (paglabag sa safe-riding obligation), ③ pagtawid ng pulang ilaw (signal violation), ④ walang ilaw sa gabi (pagmamaneho nang walang ilaw). Mas maraming paglabag, mas mabigat ang parusa.',
      id: 'Empat pelanggaran bertumpuk sekaligus: ① memegang smartphone (berkendara sambil main HP), ② earphone menghalangi suara sekitar (pelanggaran kewajiban berkendara aman), ③ menerobos lampu merah (pelanggaran sinyal), ④ tidak ada lampu malam hari (berkendara tanpa lampu). Semakin banyak pelanggaran, semakin berat sanksinya.',
      my: 'ချိုးဖောက်မှု ၄ ခု တစ်ပြိုင်နက် ဖြစ်ပွားသည်: ① smartphone ကိုင်ကာ မောင်းနင်းမှု (အာရုံလွဲ မောင်းနင်းမှု)၊ ② နားကြပ်ကြောင့် ပတ်ဝန်းကျင် အသံ မကြားနိုင်မှု (လုံခြုံသောမောင်းနှင်မှု ချိုးဖောက်မှု)၊ ③ အနီရောင်မီး ဖြတ်ကျော်မှု (မီးပြိုင့် ချိုးဖောက်မှု)၊ ④ ညဘက် မီးမပါဘဲ မောင်းနင်းမှု (မီးမပါ မောင်းနင်းမှု)။ ချိုးဖောက်မှုများ ပေါင်းလာလေ ဒဏ်ကြေးများ ပိုကြီးလေဖြစ်သည်။',
      ko: '이 행위는 4가지 위반이 동시에 겹쳐 있습니다. ①스마트폰 보유（주의분산 운전）, ②이어폰으로 주변 소리가 들리지 않음（안전 운전 의무 위반）, ③빨간 신호를 무시（신호 무시）, ④야간 라이트 없음（무등화）. 위반이 겹칠수록 처벌도 무거워집니다.',
      fr: 'Quatre infractions sont accumulées en même temps : ① tenir un smartphone (conduite distraite), ② écouteurs bloquant les sons environnants (violation de l\'obligation de conduite sécurisée), ③ griller un feu rouge (infraction au signal), ④ sans lumières la nuit (circulation sans éclairage). Plus vous cumulez d\'infractions, plus les sanctions sont lourdes.',
      it: 'Quattro violazioni si sommano contemporaneamente: ① tenere uno smartphone (guida distratta), ② auricolari che bloccano i suoni circostanti (violazione dell\'obbligo di guida sicura), ③ passare con il rosso (violazione del segnale), ④ senza luci di notte (guida senza illuminazione). Più violazioni si accumulano, più pesanti sono le sanzioni.',
      pt: 'Quatro infrações se acumulam ao mesmo tempo: ① segurar um smartphone (condução distraída), ② fones de ouvido bloqueando sons ao redor (violação da obrigação de condução segura), ③ passar no sinal vermelho (infração de sinal), ④ sem luzes à noite (circular sem iluminação). Quanto mais infrações se acumulam, mais pesadas são as penalidades.'
    },
    fineAmount: null,
    criminal: false
  },

  /* ===== Q19: ヘルメット ===== */
  {
    id: 19,
    question: {
      ja: '自転車に乗るとき、ヘルメットについて正しいのはどれですか？',
      en: 'Which statement about helmets when cycling is correct?',
      zh: '骑自行车时，关于头盔哪项说法是正确的？',
      vi: 'Điều nào đúng về mũ bảo hiểm khi đạp xe?',
      tl: 'Alin sa mga pahayag tungkol sa helmet kapag nagbibisikleta ang tama?',
      id: 'Pernyataan mana tentang helm saat bersepeda yang benar?',
      my: 'စက်ဘီးစီးနင်းသောအခါ ခေါင်းဆောင်းနှင့်ပတ်သက်ပြီး မည်သည့်ဖော်ပြချက်မှာ မှန်ကန်သနည်း?',
      ko: '자전거를 탈 때 헬멧에 대해 올바른 것은 어느 것입니까?',
      fr: 'Quelle affirmation sur le port du casque lors du vélo est correcte ?',
      it: 'Quale affermazione sul casco quando si va in bicicletta è corretta?',
      pt: 'Qual afirmação sobre capacete ao andar de bicicleta é correta?'
    },
    signImage: 'img/kiken19.png',
    category: 'その他の違反',
    choices: [
      {
        text: {
          ja: 'ヘルメットは子どもだけかぶればよい',
          en: 'Only children need to wear helmets',
          zh: '头盔只有小孩需要戴',
          vi: 'Chỉ trẻ em mới cần đội mũ bảo hiểm',
          tl: 'Ang mga bata lang ang kailangan magsuot ng helmet',
          id: 'Hanya anak-anak yang perlu memakai helm',
          my: 'ကလေးများ သာ ခေါင်းဆောင်းဆောင်းရမည်',
          ko: '헬멧은 어린이만 써야 한다',
          fr: 'Seuls les enfants doivent porter un casque',
          it: 'Solo i bambini devono indossare il casco',
          pt: 'Apenas crianças precisam usar capacete'
        },
        correct: false
      },
      {
        text: {
          ja: '大人も子どもも全員かぶることが望ましい',
          en: 'Both adults and children are encouraged to wear helmets',
          zh: '大人和小孩都应该戴头盔',
          vi: 'Cả người lớn và trẻ em đều được khuyến khích đội mũ bảo hiểm',
          tl: 'Parehong ang mga matatanda at bata ay hinihikayat na magsuot ng helmet',
          id: 'Baik orang dewasa maupun anak-anak dianjurkan untuk memakai helm',
          my: 'လူကြီးများနှင့် ကလေးများ နှစ်ဦးစလုံးသည် ခေါင်းဆောင်းဆောင်းရန် တိုက်တွန်းလိုသည်',
          ko: '어른도 어린이도 모두 쓰는 것이 바람직하다',
          fr: 'Il est conseillé que les adultes et les enfants portent tous un casque',
          it: 'È consigliato che sia gli adulti che i bambini indossino il casco',
          pt: 'É recomendável que adultos e crianças usem capacete'
        },
        correct: true
      },
      {
        text: {
          ja: 'ヘルメットはスピードを出すときだけかぶればよい',
          en: 'Helmets are only needed when riding fast',
          zh: '头盔只在快速骑行时才需要戴',
          vi: 'Mũ bảo hiểm chỉ cần khi đi nhanh',
          tl: 'Ang helmet ay kailangan lang kapag nagmamaneho nang mabilis',
          id: 'Helm hanya diperlukan saat berkendara cepat',
          my: 'မြန်မြန် မောင်းနင်းသောအခါမှသာ ခေါင်းဆောင်းဆောင်းရမည်',
          ko: '헬멧은 속도를 낼 때만 써야 한다',
          fr: 'Le casque n\'est nécessaire que lorsqu\'on roule vite',
          it: 'Il casco è necessario solo quando si pedala velocemente',
          pt: 'O capacete só é necessário quando se pedala rápido'
        },
        correct: false
      },
      {
        text: {
          ja: 'ヘルメットをかぶると視界が悪くなるので不要',
          en: 'Helmets are unnecessary because they reduce visibility',
          zh: '戴头盔会影响视野，所以没必要',
          vi: 'Mũ bảo hiểm không cần thiết vì làm giảm tầm nhìn',
          tl: 'Hindi kailangan ng helmet dahil nababawasan ang visibility',
          id: 'Helm tidak diperlukan karena mengurangi visibilitas',
          my: 'ခေါင်းဆောင်းဆောင်းလျှင် မြင်ကွင်း ကျဉ်းသောကြောင့် မလိုအပ်',
          ko: '헬멧을 쓰면 시야가 나빠지므로 불필요',
          fr: 'Le casque n\'est pas nécessaire car il réduit la visibilité',
          it: 'Il casco non è necessario perché riduce la visibilità',
          pt: 'O capacete não é necessário porque reduz a visibilidade'
        },
        correct: false
      }
    ],
    explanation: {
      ja: '2023年4月の道路交通法改正により、自転車に乗るすべての人（大人も含む）のヘルメット着用が「努力義務」になりました。罰則はありませんが、転倒時に頭を守るためにかぶることが強く推奨されています。また、自転車乗車中の死亡事故の約6割が頭部へのダメージが原因です。',
      en: 'Following the April 2023 revision of the Road Traffic Law, wearing a helmet when cycling became an "effort obligation" for all riders, including adults. There is no penalty for not wearing one, but it is strongly recommended to protect your head in a fall. About 60% of fatal bicycle accidents involve head injuries.',
      zh: '2023年4月《道路交通法》修订后，所有自行车骑行者（包括成人）佩戴头盔成为"努力义务"。虽然不戴没有罚则，但强烈建议佩戴以保护摔倒时的头部。此外，约六成自行车骑行死亡事故是由于头部受伤造成的。',
      vi: 'Sau khi Luật Giao thông được sửa đổi vào tháng 4/2023, việc đội mũ bảo hiểm khi đạp xe trở thành "nghĩa vụ cố gắng" cho tất cả người đạp xe, kể cả người lớn. Không có hình phạt nếu không đội, nhưng rất được khuyến khích để bảo vệ đầu khi ngã. Khoảng 60% tai nạn xe đạp chết người liên quan đến chấn thương đầu.',
      tl: 'Matapos ang pagbabago ng Road Traffic Law noong Abril 2023, ang pagsuot ng helmet habang nagbibisikleta ay naging "effort obligation" para sa lahat ng mangangagad, kasama ang mga matatanda. Walang parusa para sa hindi pagsuot, ngunit lubos itong inirerekomenda para protektahan ang ulo sa pagkahulog. Humigit-kumulang 60% ng mga nakamamatay na aksidente sa bisikleta ay kinasasangkutan ng pinsala sa ulo.',
      id: 'Setelah revisi UU Lalu Lintas April 2023, mengenakan helm saat bersepeda menjadi "kewajiban upaya" bagi semua pengendara, termasuk orang dewasa. Tidak ada sanksi untuk tidak memakainya, tetapi sangat dianjurkan untuk melindungi kepala saat jatuh. Sekitar 60% kecelakaan sepeda fatal melibatkan cedera kepala.',
      my: '၂၀၂၃ ဧပြီလ လမ်းအသွားအလာ ဥပဒေ ပြင်ဆင်ပြီးနောက်၊ စက်ဘီးစီးနင်းသူ အားလုံး (လူကြီးများ အပါအဝင်) ခေါင်းဆောင်းဆောင်းရခြင်းသည် "ကြိုးစားမှု တာဝန်ဝတ္တရား" ဖြစ်လာသည်။ မဆောင်းရသည့် ဒဏ်ကြေး မရှိသော်လည်း ကျသောအခါ ခေါင်းကာကွယ်ရန် အလွန် တိုက်တွန်းသည်။ စက်ဘီးစီးနင်းရင်း သေဆုံးမှု မတော်တဆဆိုးမှုများ၏ ၆၀% ခန့်သည် ခေါင်းဒဏ်ကြောင့် ဖြစ်သည်။',
      ko: '2023년 4월 도로교통법 개정으로 자전거를 타는 모든 사람（어른 포함）의 헬멧 착용이 "노력 의무"가 되었습니다. 처벌은 없지만 넘어질 때 머리를 보호하기 위해 착용하는 것이 강력히 권장됩니다. 또한 자전거 탑승 중 사망 사고의 약 60%가 두부 손상이 원인입니다.',
      fr: 'Suite à la révision du Code de la route d\'avril 2023, le port du casque en vélo est devenu une « obligation d\'effort » pour tous les cyclistes, adultes inclus. Il n\'y a pas de sanction pour non-port, mais il est vivement recommandé pour protéger la tête en cas de chute. Environ 60 % des accidents de vélo mortels impliquent des blessures à la tête.',
      it: 'In seguito alla revisione del Codice della Strada dell\'aprile 2023, indossare il casco in bicicletta è diventato un "obbligo di sforzo" per tutti i ciclisti, adulti inclusi. Non ci sono sanzioni per chi non lo indossa, ma è vivamente raccomandato per proteggere la testa in caso di caduta. Circa il 60% degli incidenti mortali in bicicletta coinvolge lesioni alla testa.',
      pt: 'Após a revisão da Lei de Trânsito de abril de 2023, usar capacete ao pedalar tornou-se uma "obrigação de esforço" para todos os ciclistas, incluindo adultos. Não há penalidade por não usá-lo, mas é fortemente recomendado para proteger a cabeça em caso de queda. Cerca de 60% dos acidentes fatais de bicicleta envolvem lesões na cabeça.'
    },
    fineAmount: null,
    criminal: false
  },

  /* ===== Q20: 歩行者へのぶつかり（責任） ===== */
  {
    id: 20,
    question: {
      ja: '自転車で走っていて、不注意で歩行者にぶつかってケガをさせてしまいました。このとき自転車側はどうなりますか？',
      en: 'While cycling, you carelessly collided with a pedestrian and injured them. What happens to the cyclist?',
      zh: '骑自行车时不小心撞到行人并导致其受伤。骑车人会面临什么？',
      vi: 'Trong khi đạp xe, bạn vô tình va vào người đi bộ và làm họ bị thương. Người đạp xe sẽ phải đối mặt với gì?',
      tl: 'Habang nagbibisikleta, hindi mo sinasadyang nabangga ang isang pedestrian at nagpahirap sa kanya. Ano ang mangyayari sa cyclist?',
      id: 'Saat bersepeda, Anda tidak sengaja menabrak pejalan kaki dan melukai mereka. Apa yang terjadi pada pesepeda?',
      my: 'စက်ဘီးစီးနင်းစဉ် သတိမထားမိဘဲ လမ်းလျှောက်သူနှင့် တိုက်မိကာ ဒဏ်ရာရစေသည်။ ဤအခါ စက်ဘီးသမားမည်သို့ ဖြစ်မည်နည်း?',
      ko: '자전거를 타다가 부주의로 보행자와 부딪혀 부상을 입혔습니다. 이때 자전거 측은 어떻게 됩니까?',
      fr: 'En faisant du vélo, vous avez maladroitement heurté un piéton et l\'avez blessé. Qu\'arrive-t-il au cycliste ?',
      it: 'Mentre andavi in bicicletta, hai inavvertitamente urtato un pedone e l\'hai ferito. Cosa succede al ciclista?',
      pt: 'Enquanto pedalava, você inadvertidamente colidiu com um pedestre e o feriu. O que acontece com o ciclista?'
    },
    signImage: 'img/kiken20.png',
    category: '歩行者妨害',
    choices: [
      {
        text: {
          ja: '自転車は軽いので責任は軽い',
          en: 'Bicycles are light so the liability is minor',
          zh: '自行车轻，所以责任也轻',
          vi: 'Xe đạp nhẹ nên trách nhiệm cũng nhẹ',
          tl: 'Magaan ang bisikleta kaya magaan din ang responsibilidad',
          id: 'Sepeda ringan sehingga tanggung jawabnya juga ringan',
          my: 'စက်ဘီး ပေါ့သောကြောင့် တာဝန်ယူမှုလည်း ပေါ့ပါသည်',
          ko: '자전거는 가벼우므로 책임도 가볍다',
          fr: 'Les vélos sont légers, donc la responsabilité est mineure',
          it: 'Le biciclette sono leggere quindi la responsabilità è minima',
          pt: 'As bicicletas são leves, então a responsabilidade é mínima'
        },
        correct: false
      },
      {
        text: {
          ja: 'ぶつかった相手が悪いので責任はない',
          en: 'The other person is at fault so there is no liability',
          zh: '是对方的错，所以没有责任',
          vi: 'Người kia có lỗi nên không có trách nhiệm',
          tl: 'Kasalanan ng ibang tao kaya walang responsibilidad',
          id: 'Kesalahan orang lain jadi tidak ada tanggung jawab',
          my: 'တိုက်မိသူ အပြစ်ရှိသောကြောင့် တာဝန်မရှိ',
          ko: '부딪힌 상대가 나쁘므로 책임이 없다',
          fr: 'L\'autre personne est fautive donc il n\'y a pas de responsabilité',
          it: 'L\'altra persona è in colpa quindi non c\'è responsabilità',
          pt: 'A outra pessoa é culpada, então não há responsabilidade'
        },
        correct: false
      },
      {
        text: {
          ja: '「ごめんなさい」と謝れば解決する',
          en: 'Saying "I\'m sorry" resolves the issue',
          zh: '道歉就能解决',
          vi: 'Nói "Xin lỗi" là giải quyết được vấn đề',
          tl: 'Ang pagsasabing "Pasensya na" ay nakakalutas ng problema',
          id: 'Mengucapkan "Maaf" sudah menyelesaikan masalah',
          my: '"ငါ့ကို ခွင့်လွှတ်ပါ" ဟုပြောလျှင် ဖြေရှင်းနိုင်သည်',
          ko: '"미안합니다"라고 사과하면 해결된다',
          fr: 'Dire « Pardon » résout le problème',
          it: 'Dire "Mi dispiace" risolve il problema',
          pt: 'Dizer "Me desculpe" resolve o problema'
        },
        correct: false
      },
      {
        text: {
          ja: '相手の治療費などを払う責任が生じる',
          en: 'You become liable to pay for the other person\'s medical expenses and more',
          zh: '将承担支付对方医疗费等的责任',
          vi: 'Bạn có trách nhiệm trả chi phí y tế và hơn thế nữa',
          tl: 'Mananagot ka sa pagbabayad ng medikal na gastos at iba pa ng ibang tao',
          id: 'Anda bertanggung jawab membayar biaya medis dan lainnya',
          my: 'တဖက်သားသည့် ကုသစရိတ် နှင့် ဆက်သွယ်မှုများ ပေးဆောင်ရသည့် တာဝန်ဝတ္တရားများ ပေါ်ပေါက်သည်',
          ko: '상대방의 치료비 등을 지불할 책임이 생긴다',
          fr: 'Vous devenez responsable du paiement des frais médicaux et autres de l\'autre personne',
          it: 'Siete responsabili del pagamento delle spese mediche e altro dell\'altra persona',
          pt: 'Você se torna responsável pelo pagamento das despesas médicas e mais da outra pessoa'
        },
        correct: true
      }
    ],
    explanation: {
      ja: '自転車で歩行者にぶつかってケガをさせると、治療費や慰謝料などを払う責任（民事責任）が生じます。場合によっては何百万円もの賠償になることもあります。自転車保険に加入していれば保険で対応できます。自転車に乗るときは常に「もし誰かにぶつかったら」と意識して安全運転を心がけましょう。',
      en: 'If you injure a pedestrian by cycling into them, you become civilly liable to pay their medical costs, compensation for pain, and more. In some cases this can reach millions of yen. Bicycle insurance can cover such costs. Always ride with the awareness that you could injure someone, and make safety your top priority.',
      zh: '骑自行车撞伤行人后，将产生支付治疗费和慰问金等的民事责任。有时赔偿金额可能高达数百万日元。如有自行车保险可通过保险处理。骑车时，请时刻意识到"如果撞到某人"，注意安全驾驶。',
      vi: 'Nếu bạn làm người đi bộ bị thương khi đạp xe, bạn sẽ có trách nhiệm dân sự để trả chi phí y tế, bồi thường thiệt hại và hơn thế nữa. Trong một số trường hợp, có thể lên đến hàng triệu yên. Bảo hiểm xe đạp có thể chi trả cho những chi phí như vậy. Luôn đạp xe với ý thức rằng bạn có thể gây thương tích cho ai đó.',
      tl: 'Kung maaari kang manggulo ng pedestrian sa pamamagitan ng pagbibisikleta sa kanila, mananagot ka sa sibil para bayaran ang kanilang medikal na gastos, kabayaran para sa sakit at higit pa. Sa ilang kaso ito ay maaaring umabot sa milyun-milyong yen. Ang bicycle insurance ay maaaring masaklaw ang gayong gastos. Palaging sumakay nang may kamalayan na maaari kang makapinsala ng isang tao.',
      id: 'Jika Anda melukai pejalan kaki dengan menabraknya saat bersepeda, Anda bertanggung jawab secara perdata untuk membayar biaya medis, ganti rugi, dan lainnya. Dalam beberapa kasus ini bisa mencapai jutaan yen. Asuransi sepeda bisa menanggung biaya tersebut. Selalu berkendara dengan kesadaran bahwa Anda bisa melukai seseorang.',
      my: 'စက်ဘီးစီးနင်းကာ လမ်းလျှောက်သူတစ်ဦးကို ဒဏ်ရာရစေလျှင်၊ သင်သည် သူတို့၏ ဆေးကုစရိတ်၊ နစ်နာကြေး နှင့် အခြားများကို ပေးဆောင်ရမည့် တရားဝင်တာဝန်ယူမှု ရှိလာသည်။ အချို့ကိစ္စများတွင် ဆယ်သောင်းနှင့်ချီ၍ မြောက်နိုင်သည်။ စက်ဘီးအာမခံ ရှိပါက ကာမိနိုင်သည်။ မောင်းနင်းသည့်အခါ "တစ်ဦးကို ဒဏ်ရာရစေနိုင်သည်" ဟု အမြဲ သတိရပြီး လုံခြုံသောမောင်းနှင်မှုကို ဦးစားပေးပါ။',
      ko: '자전거로 보행자와 부딪혀 부상을 입히면 치료비나 위자료 등을 지불할 책임（민사 책임）이 생깁니다. 경우에 따라서는 수백만 엔의 배상이 될 수도 있습니다. 자전거 보험에 가입하고 있으면 보험으로 대응할 수 있습니다. 자전거를 탈 때는 항상 "만약 누군가에게 부딪힌다면"을 의식하고 안전 운전을 합시다.',
      fr: 'Si vous blessez un piéton en le heurtant à vélo, vous devenez civilement responsable du paiement de ses frais médicaux, de son indemnisation et plus encore. Dans certains cas, cela peut atteindre des millions de yens. Une assurance vélo peut couvrir de tels coûts. Roulez toujours avec la conscience que vous pourriez blesser quelqu\'un.',
      it: 'Se si ferisce un pedone investendolo in bicicletta, si diventa civilmente responsabili del pagamento delle sue spese mediche, del risarcimento e altro ancora. In alcuni casi ciò può arrivare a milioni di yen. Un\'assicurazione per biciclette può coprire tali costi. Andate sempre in bicicletta con la consapevolezza di poter ferire qualcuno.',
      pt: 'Se você ferir um pedestre ao colidir com ele de bicicleta, você se tornará civilmente responsável por pagar suas despesas médicas, compensação e mais. Em alguns casos isso pode chegar a milhões de ienes. Um seguro de bicicleta pode cobrir esses custos. Sempre pedale com a consciência de que pode ferir alguém.'
    },
    fineAmount: null,
    criminal: true
  }

]; /* /QUIZ_DATA */

